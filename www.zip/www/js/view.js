function addSpinner(id, topMargin){
    var sp = '<div id="'+id+'" class="SYS_LOADER">'+
                 '<div style="top:'+topMargin+'%" class="col s12 center" data-role="scroll-data-loader">'+
                    '<div class="preloader-wrapper big active">'+
                        '<div class="spinner-layer spinner-blue-only">'+
                            '<div class="circle-clipper left">'+
                                '<div class="circle"></div>'+
                            '</div>'+
                            '<div class="gap-patch">'+
                                '<div class="circle"></div>'+
                            '</div>'+
                            '<div class="circle-clipper right">'+
                                '<div class="circle"></div>'+
                            '</div>'+
                        '</div>'+
                    '</div>'+
                  '</div>'+
                '</div>';
    return sp;
}

function spinnerVisibility(id, visible){
//    console.log('id - '+id+'    visible - '+visible);
    if(visible){
        $('#'+id).show();
    }else{
        $('#'+id).remove();
    }
}

RATINGCOLOURARR = {
                    '1': '#FF8B5A',
                    '2': '#FFB233',
                    '3': '#FFEA3A',
                    '4': '#CCDB38',
                    '5': '#8AC249',
                   }

function addRatingView(total_rating, avg_rating){
    var rating = '<div class="row">'+
			     		'<div class="col s12">'+
			     			'<div class="card white darken-1" style="margin-bottom:10px;">'+
				     			'<div class="col s12 white darken-1" style="padding: 0;margin:0px 0 0px 10px;">'+
				     				'<span style="width:100%;display:table;float:left;text-align:center;font-size:20px;padding-top:10px;color:#777;">'+
				     					'<div style="width:90%;float:left">Reviews & Ratings</div>'+
//				     					'<div style="width:10%;float:left"><i class="fa fa-angle-right"></i></div>'+
				     				'</span>'+
				     			'</div>'+
				     			'<div class="col s12" style="padding:10px 0">'+
				          			'<div class="col s6 center">'+
										'<div class="col s12" style="font-size: 40px;text-align:left;border-right:1px solid #ccc;color:'+RATINGCOLOURARR[Math.ceil(avg_rating)]+'">'+
											'<div class="col s12">'+(avg_rating)+'</div>'+
											'<div class="col s12">'+
		              							'<span class="stars">'+parseInt(avg_rating)+'</span>'+
		              						'</div>'+
										'</div>'+
									'</div>'+
									'<div class="col s6">'+
										'<div class="col s12" style="text-align:right">'+
											'<div style="font-size:32px;color:#777" class="col s12">'+total_rating+'</div>'+
											'<div style="font-size:20px;" class="col s12">Votes</div>'+
										'</div>'+
									'</div>'+
								'</div>'+
							'</div>'+
						'</div>'+
					'</div>';
    return rating;
}


function addUpdateView(id, callbackFunctionName, topMargin){
    var update = '<div id="'+id+'" style="background-color:#fff;padding:10px;height:50px;margin-top:'+topMargin+'px"><span style="color:#1b5e20;font-size:17px;float:left;"><b>New Update Available!</b></span><a onclick="'+callbackFunctionName+'();" class="waves-effect waves-light btn-small col s12" style="background-color:#5a0f5a;color:#fff;float:right;padding:5px;">Update Now</a></div>';
    return update;
}