var color = {
                "base_color": "#5a0f5a", 
                "base_color_light": "#5a0f5a",
                "white": "#fff",
                "grey_light": "#EFF3F8",
                "grey_dark": "#777",
                "grey_dark_2": "#666",
                "blue": "#42a5f5",
                "green": "#8bc34a",
                "green_dark": "#388E3C",
                "green_dark_1": "#1b5e20",
                "light_1": "#e0e0e0",
                "black": "#000",
                "white_1": "#EFF3F8",
                "red": "#b71c1c"
            };

var appVersion;
var updateAppURL;
var OSName = "Android";

String.prototype.sectodate = Number.prototype.sectodate =  function(format){
		//alert(this);
		//var temp = (this).split(" ");
		//var d = new Date(temp[0]);
		var d = new Date(this);
		//alert(d);
		var str = d.getFullYear()+'-'+(d.getMonth()+1)+'-'+(d.getDate()) +' '+d.getHours()+':'+d.getMinutes()+':'+d.getSeconds();
		//alert(str);
		return str.strtodate(format);
	}
	
String.prototype.pad = Number.prototype.pad = function(size) {
    var s = String(this);
    if(typeof(size) !== "number"){size = 2;}

    while (s.length < size) {s = "0" + s;}
    return s;
};

String.prototype.strtodate = function(format){
    //alert(format);
    var str = String(this);
    var temp = str.split(' ');
    var params = [temp[0].split('-'),temp[1].split(':')];
    var months = ["","January","Febuary","March","April","May","June","July","August","September","October","November","December"];
    var date = "";
    for(var i = 0 ; i < format.length; i++){
        switch(format[i]){
            case "d" : date += parseInt(params[0][2]).pad(2);break;
            case "j" : date += parseInt(params[0][2]);break;
            case "F" : date += months[parseInt(params[0][1])];break;
            case "m" : date += parseInt(params[0][1]).pad(2);break;
            case "M" : date += months[parseInt(params[0][1])].substr(0,3);break;
            case "n" : date += parseInt(params[0][1]);break;
            case "Y" : date += params[0][0];break;
            case "y" : date += params[0][0].substr(2,2);break;
            case "a" : date += parseInt(params[1][0]) > 11 ? 'pm':'am' ;break;
            case "a" : date += parseInt(params[1][0]) > 11 ? 'PM':'AM' ;break;
            case "g" : date += parseInt(params[1][0]) > 12 ? (parseInt(params[1][0]) - 12) : parseInt(params[1][0])  ;break;
            case "h" : date += parseInt(params[1][0]) > 12 ? (parseInt(params[1][0]) - 12).pad(2) : parseInt(params[1][0]).pad(2);break;
            case "G" : date += parseInt(params[1][0]);break;
            case "H" : date += parseInt(params[1][0]).pad(2);break;
            case "i" : date += parseInt(params[1][1]).pad(2);break;
            case "s" : date += parseInt(params[1][2]).pad(2);break;
            default  : date += format[i];
        }
    }
    //alert(date);
    return date;
};

function checkForUpdate(response, OSName){
//    console.log("checkForUpdate - "+response);
//        var response = res;
    if(res !== undefined || res !== ''){
        var tempVersion = appVersion;
        tempVersion.replaceAll
        tempVersion = tempVersion.split(".").join("");
        var av = response.av.split(".").join("");
        var iv = response.iv.split(".").join("");
//        console.log("av = "+av);
//        console.log("tempVersion = "+tempVersion);
//        console.log("OSName = "+OSName);
        if(OSName === "Android"){
            if(parseInt(av) > parseInt(tempVersion)){
//                console.log('Android Update');
                setUpdateAvailable(true);
                updateAppURL = response.aurl;
                setUpdateUrl(response.aurl);
            }else{
                setUpdateAvailable(false);
            }    
        }else if(OSName === "iOS"){
            if(parseInt(iv) > parseInt(tempVersion)){
//                console.log('iOS Update');
                setUpdateAvailable(true);
                updateAppURL = response.iurl;
                setUpdateUrl(response.iurl);
            }else{
                setUpdateAvailable(false);
            }    
        }else{
            setUpdateAvailable(false);
        }
        
    }
//    console.log('isUpdateAvailable - '+isUpdateAvailable());
    var upd = isUpdateAvailable();
    if(upd === "true"){
//        console.log('show');
        $('#update_div').show();
    }else{
//        console.log('hide');
        $('#update_div').hide();
    }
}

function getUpdateAppLink(){
    return updateAppURL;
}

function updateApp(){
    console.log(getUpdateUrl());
    intel.xdk.device.launchExternal(getUpdateUrl());
}

function isValidJson(jsonStr){
   try {
        JSON.parse(jsonStr);
    } catch (e) {
        return false;
    }
    return true;
}

function getStageConfig(){
    var stageResponse = '{"data": {"login": "https://stage.nvy.com/api/merchant_dashboard/login","dashboard": {"yearly": "https://stage.nvy.com/api/merchant_dashboard/dashboard?t=yearly","monthly": "https://stage.nvy.com/api/merchant_dashboard/dashboard?t=monthly","daily": "https://stage.nvy.com/api/merchant_dashboard/dashboard?t=daily"},"offers": "https://stage.nvy.com/api/merchant_dashboard/offers","redeem": "https://stage.nvy.com/api/merchant_dashboard/redeem","deal": "https://stage.nvy.com/api/merchant_dashboard/deal?oc=","merchant": "https://stage.nvy.com/api/merchant_dashboard/merchant?mc=","payments": {"list": "https://stage.nvy.com/api/merchant_dashboard/payment","utr_code": "https://stage.nvy.com/api/merchant_dashboard/payment?utr="},"ratings": "https://stage.nvy.com/api/merchant_dashboard/ratings","contact": "https://stage.nvy.com/api/merchant_dashboard/contact","outlets": "https://stage.nvy.com/api/merchant_dashboard/outlets"},"av": "2.0.2","iv": "2.0.2","aurl": "https://play.google.com/store/apps/details?id=com.little.partnerhub","iurl": "https://itunes.apple.com/in/app/partnerhub-by-little/id1063099045"}';
    return stageResponse;
}


$(document).ready(function(){
    appVersion = "2.0.2";
});