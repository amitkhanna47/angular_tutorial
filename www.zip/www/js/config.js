var config = {
//    "data":{
//      "login": "https://stage.nvy.com/api/merchant_dashboard/login",
//      "dashboard": {
//        "yearly": "https://stage.nvy.com/api/merchant_dashboard/dashboard",
//        "monthly": "https://stage.nvy.com/api/merchant_dashboard/dashboard?t=monthly",
//        "daily": "https://stage.nvy.com/api/merchant_dashboard/dashboard?t=daily",
//      },
//      "offers": "https://stage.nvy.com/api/merchant_dashboard/offers",
//      "redeem": "https://stage.nvy.com/api/merchant_dashboard/redeem",
//      "payments": {
//        "list": "https://stage.nvy.com/api/merchant_dashboard/payment",
//        "utr_code": "https://stage.nvy.com/api/merchant_dashboard/payment?utr="
//      },
//      "ratings": "https://stage.nvy.com/api/merchant_dashboard/ratings",
//      "contact": "https://stage.nvy.com/api/merchant_dashboard/contact"
//    }    
}

function getSavedConfig(){
    var db = getLocalStorage();
    return JSON.parse(db.getItem('config'));
}

function setConfig(configDY){
    var db = getLocalStorage();
    config = configDY;
    db.setItem('config',JSON.stringify(configDY));
}

function setUpdateUrl(url){
    var db = getLocalStorage();
    db.setItem('update_url',url);
}

function getUpdateUrl(){
    var db = getLocalStorage();
    return db.getItem('update_url');
}

function isUpdateAvailable(){
    var db = getLocalStorage();
    return db.getItem('update_available');
}

function setUpdateAvailable(isAvail){
    var db = getLocalStorage();
    return db.setItem('update_available', isAvail);
}

function getLocalStorage(){
    try{
        if(window.localStorage ) return window.localStorage;            
    }
    catch(e){
        return undefined;
    }
}