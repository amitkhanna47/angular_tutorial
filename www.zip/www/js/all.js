// var jquery = document.createElement('script');
// jquery.type = 'text/javascript';
// jquery.src = url;
var userHistory = new Array();
var selectedOptionForOutlet = "";
var isOutletDropDown = false;
var globalOutlet = false;
var nwErrorCheck;
var scroller ;
var jsFiles = {
				0 : {src:'cordova.js',id:"xdkJScordova_"},
				1 : {src:'js/app.js'},
				2 : {src:'js/init-app.js'},
				3 : {src:'xdk/init-dev.js'},
				4 : {src:'lib/jquery.min.js',type:'application/javascript'},
				5 : {src:'sidebar/js/hammer.js',type:'application/javascript'},
				6 : {src:'sidebar/js/jquery.hammer.js',type:'application/javascript'},
				7 : {src:'sidebar/js/swipe-hammer.js',type:'application/javascript'},
				8 : {src:'sidebar/js/sidebar.js',type:'application/javascript'},
				9 : {src:'js/index_user_scripts.js',type:'application/javascript'},
				10 : {src:'xdk/ad/bs_subpage.js',type:'application/javascript'}
			  };  
			  
			  
function load(){
	var BASE_URL = '../';
	var head = document.getElementsByTagName('head')[0];
	for(var i=0;i<=10;i++){
		var script = document.createElement('script');
			script.src = BASE_URL+jsFiles[i].src;
			if(jsFiles[i].id!==undefined){
				script.id = jsFiles[i].id;
			}
			
			if(jsFiles[i].type!==undefined){
				script.type = jsFiles[i].type;
			}
		 head.appendChild(script);
	}	
}
//load();
//$("head").append('<script type="text/javascript" src="' + script + '"></script>');

	$(document).ready(function(){
		var db = getLocalStorage();
		var merchantCode = db.getItem('merchantCode');
        globalMerchantCode = merchantCode;
		//var token = db.getItem('token');
		//var password = db.getItem('password');
		
		var apiKey = db.getItem('apiKey');
		var publicKey = db.getItem('publicKey');
		var passhash = CryptoJS.MD5(apiKey+publicKey);
		config = getSavedConfig();
        if(config === undefined || config === ''){
            logout();
        }
		if(merchantCode  === '' || merchantCode === null || merchantCode === undefined){
			window.location.assign("../index.html");
		}
//		console.log(config);
		little.constants.API = {
			/*OFFERS		: 'https://nvy.com/api/dashboard/merchant?q={"mc":"'+merchantCode+'","t":"d"}',
			DASHBOARD		: 'https://nvy.com/api/dashboard/merchant?q={"mc":"'+merchantCode+'","t":"r"}',
			PAYMENTHISTORY	: 'https://nvy.com/api/dashboard/merchant?q={"mc":"'+merchantCode+'","t":"p"}',
			RATING			: 'https://nvy.com/api/dashboard/merchant?q={"mc":"'+merchantCode+'","t":"rr"}',
			REDEMPTION		: 'https://nvy.com/api/vendor/redeem',
			CALLBACK	    : 'https://nvy.com/api/dashboard/merchant?q={"mc":"'+merchantCode+'","t":"rac"}',*/
			
//			OFFERS			: 'https://nvy.com/api/dashboard/merchant?q={"t":"d"}',
//			DASHBOARD		: 'https://nvy.com/api/dashboard/merchant?q={"t":"mr"}',
//			//DASHBOARD		: 'https://nvy.com/api/dashboard/merchant?q={"t":"r"}',
//			PAYMENTHISTORY	: 'https://nvy.com/api/dashboard/merchant?q={"t":"mp"}',
//			//PAYMENTHISTORY	: 'https://nvy.com/api/dashboard/merchant?q={"t":"p"}',
//			RATING			: 'https://nvy.com/api/dashboard/merchant?q={"t":"mrr"}',
//			//RATING			: 'https://nvy.com/api/dashboard/merchant?q={"t":"rr"}',
//			REDEMPTION		: 'https://nvy.com/api/vendor/redeem',
//			CALLBACK	    : 'https://nvy.com/api/dashboard/merchant?q={"t":"rac"}',
//			
//			REDEMPTIONCHECK : 'https://nvy.com/api/dashboard/merchant?q={"t":"ismrq"}',
            
            // New API Changes
            DASHBOARD_MONTHY_REVENUE: config.data.dashboard.monthly,
            DASHBOARD_YEARLY_REVENUE: config.data.dashboard.yearly,
            DASHBOARD_DAILY_REVENUE: config.data.dashboard.daily,
            DASHBOARD_PAYMENT: config.data.payments.list,
            DASHBOARD_PAYMENT_UTR: config.data.payments.utr_code,
            DASHBOARD_OFFERS: config.data.offers,
            DASHBOARD_CONTACT: config.data.contact,
            DASHBOARD_REDEEM: config.data.redeem,
            DASHBOARD_DEAL: config.data.deal,
            DASHBOARD_OUTLETS: config.data.outlets
		}
		
		
		little.constants.LITTLE_HEADERS = {
			//VALUES : {'t':token,'p':'+919845035265','k':password},
			VALUES : {'t':passhash,'p': merchantCode},
		}
		
		
		little.controllers.template();
        
		$(document).scroll(function(){
			
			$('[data-role="ajax-data-table"]').each(function(){
			var bottomDistance = parseInt($(this).attr('bottom-distance')); 
				if($(window).scrollTop() + $(window).height() > $(document).height() - bottomDistance) {
									
		    		$('[data-role="ajax-data-table"][is-scrollable="true"]').trigger('scroll-data');	
	   			}
			});
		});
		     
		var ABC;
        var spinner_count = 0;
        var dash_check = false;
        nwErrorCheck = false;
		$(document).on('scroll-data', '[data-role="ajax-data-table"]',function(){
			//little.views.vw_networkErrorMsg
			//$('#mNameWrap').remove();
			$("div:visible[id*='mNameWrap']").remove();
			var url       = $(this).attr('data-url');
			var type = (($(this).attr('data-url-type'))==undefined || ($(this).attr('data-url-type'))=='')?'GET':$(this).attr('data-url-type');			
			var responseType = ($(this).attr('response-type')==undefined || $(this).attr('response-type')=='')?'string':$(this).attr('response-type');
			var pageNo    = parseInt($(this).attr('data-page-no'));
			var limit     = parseInt($(this).attr('data-limit'));
			var isLoading = $(this).attr('is-loading');
			var callback  = $(this).attr('callback');
			var obj = this;
            var showErrorToast = false;
			var errorMsg = "";
			
			if(isLoading == true || isLoading == 'true'){
				return;
			}
			
			if(pageNo=='' || pageNo==undefined || isNaN(pageNo)){
				url = url;
			}else{
				url = url+'/'+pageNo+'/'+limit;
			}
			if(ABC != undefined){
				//ABC.abort();
			}
            spinner_count++;
//            if(spinner == 1){
//                $(obj).append('<div class="col s12 center" data-role="scroll-data-loader">'+
//				        				 '<div class="preloader-wrapper big active">'+
//										    '<div class="spinner-layer spinner-blue-only">'+
//										      '<div class="circle-clipper left">'+
//										        '<div class="circle"></div>'+
//										      '</div><div class="gap-patch">'+
//										        '<div class="circle"></div>'+
//										      '</div><div class="circle-clipper right">'+
//										        '<div class="circle"></div>'+
//										      '</div>'+
//										    '</div>'+
//										  '</div>'+
//									   '</div>');    
//            }
//            
            var dm;
			ABC = $.ajax({
		        url: url,
		        type: type,
		        beforeSend: function(xhr){
		        	//$(obj).attr('is-loading',true);
		        	$.each(little.constants.LITTLE_HEADERS.VALUES,function(index,value){
						xhr.setRequestHeader(index,value);	
					});
		        	
		        	$(obj).attr('is-loading','true');
//                    console.log('url - '+url);
                    
                    if(url === ''){
                        spinner_count = 0;
                        return;
                    }
                    
                    if(url === little.constants.API.DASHBOARD_DAILY_REVENUE || 
                          url === little.constants.API.DASHBOARD_MONTHY_REVENUE ||
                          url === little.constants.API.DASHBOARD_YEARLY_REVENUE){
                        dash_check = true;
                    }else{
                        dash_check = false;
                    }
//                    console.log('spinner_count - '+spinner_count);
//                    console.log('dash_check - '+dash_check);
                    if(dash_check == false){
                        $(obj).append('<div class="col s12 center" data-role="scroll-data-loader" style="z-index:2000">'+
				        				 '<div class="preloader-wrapper big active" style="z-index:2000">'+
										    '<div class="spinner-layer spinner-blue-only" style="z-index:2000">'+
										      '<div class="circle-clipper left">'+
										        '<div class="circle" style="z-index:2000"></div>'+
										      '</div><div class="gap-patch">'+
										        '<div class="circle"></div>'+
										      '</div><div class="circle-clipper right">'+
										        '<div class="circle"></div>'+
										      '</div>'+
										    '</div>'+
										  '</div>'+
									   '</div>');
                        $('#top_loader').hide();
                    }else{
                        $('#top_loader').show();
                    }
                    if(spinner_count == 1 && dash_check){
//                        console.log('spinner true');
                        $('#content-wrapper').show();
//                        Materialize.toast('Fetching Data...', 3000,'top').show();
//                        $(obj).append('<div class="col s12 center" data-role="scroll-data-loader" style="z-index:2000">'+
//				        				 '<div class="preloader-wrapper big active" style="z-index:2000">'+
//										    '<div class="spinner-layer spinner-blue-only" style="z-index:2000">'+
//										      '<div class="circle-clipper left">'+
//										        '<div class="circle" style="z-index:2000"></div>'+
//										      '</div><div class="gap-patch">'+
//										        '<div class="circle"></div>'+
//										      '</div><div class="circle-clipper right">'+
//										        '<div class="circle"></div>'+
//										      '</div>'+
//										    '</div>'+
//										  '</div>'+
//									   '</div>');
                    }else if(spinner_count > 3 && dash_check){
//                        console.log('spinner else > 3');
                        spinner_count = 0;
                    }else if(dash_check === false){
                        spinner_count = 0;
//                        console.log('spinner else false');
                        $('#content-wrapper').show();
//                        Materialize.toast('Fetching Data...', 3000,'top').show();
//                        $(obj).append('<div class="col s12 center" data-role="scroll-data-loader">'+
//				        				 '<div class="preloader-wrapper big active">'+
//										    '<div class="spinner-layer spinner-blue-only">'+
//										      '<div class="circle-clipper left">'+
//										        '<div class="circle"></div>'+
//										      '</div><div class="gap-patch">'+
//										        '<div class="circle"></div>'+
//										      '</div><div class="circle-clipper right">'+
//										        '<div class="circle"></div>'+
//										      '</div>'+
//										    '</div>'+
//										  '</div>'+
//									   '</div>');
                    }
		        	
		        },
		        
		        async: true,
	            success: function(response){
//                    console.log(response);
	            	$(obj).find('[data-role="scroll-data-loader"]').remove();
	            	$(obj).attr('is-loading','false');
	            	$(obj).attr('data-page-no', ++pageNo);
		            if(responseType=='json'){
		            	var data=$.parseJSON(response);
		            }else{
		            	var data=response;
//		            	console.log(data.ec+' -- saurabh');
		            }
                    if(data.dm != undefined){
                        showErrorToast = true;
                        errorMsg = data.dm;
                    }     
		            if(data.ec == -100 && data.ec !=undefined){
		            	//alert("hi");
		            	logout();
		            }
                    else{
		            	little.views[callback](data,obj);
		            }
	            },
	            error: function (xhr,request, status, error) {
//            console.log("parent xhr - "+xhr.status);
            $('#top_loader').hide();
	            	if(status != 'abort'){
//                        console.log(xhr.responseText);
                        var dm = "";
                        if(isValidJson(xhr.responseText)){
                            dm = $.parseJSON(xhr.responseText);
                        }else{
                            dm = "Something went wrong!"
                        }
                        $(obj).find('[data-role="scroll-data-loader"]').remove();
//                        console.log('url - '+url);
                        if(url === "asdadasd" || url === "dummy_url"){
                            globalOutlet = true;
                            little.views[callback](xhr.responseText,obj);
                        }else{
                            globalOutlet = false;
                            little.views.vw_networkErrorMsg(dm);        
                        }
                    }
				        
				},
                complete: function(xhr, textStatus) {
//                    console.log(xhr.status);
                    var statusCode = parseInt(xhr.status);
                    if(!(statusCode == 400 || statusCode == 500 || statusCode == 404)){
                        if(showErrorToast)
                            Materialize.toast(errorMsg, 3000,'center');
                    }
                    if(statusCode >=400 && statusCode <= 500){
                        globalOutlet = true;
                    }else{
                        globalOutlet = false;
                    }
                } 
		     });
		});

	});
	
    function confirm_callback(e) {
        //e.id represents the id of the confirm box
        if(e.id == "confirm_box1")
        {
            if(e.success == true && e.answer == true)
            {
                //first button clicked.

            }
            else
            {
                //second button clicked
            }
        }
        else if(e.id == "confirm_box2")
        {
            if(e.success == true && e.answer == true)
            {
                //first button clicked.
            }
            else
            {
                //second button clicked
            }
        }
    }
	
	var little = {};
    var monthNames = ["January", "February", "March", "April", "May", "June",
                            "July", "August", "September", "October", "November", "December"
                            ];
    var dayNames = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday",
                            "Sunday"];
    
	
	little.constants = {
		BASE_URL: window.location.origin+'/',
		
	};
	
	little.constants.RATINGCOLOURARR = {
		'1': '#FF8B5A',
	    '2': '#FFB233',
	    '3': '#FFEA3A',
	    '4': '#CCDB38',
	    '5': '#8AC249',
	}
	

	little.controllers = {};
	little.views = {};
	
	
	little.views.vw_dashboard = function(res){
		//$("div:visible[id*='mNameWrap']").remove();
		userHistory[userHistory.length] = 'vw_dashboard';
		
		/*var db = getLocalStorage();		
		//alert(db.getItem('merchantName'));
		if(db.getItem('merchantName') == undefined || db.getItem('merchantName') == 'undefined'){
			var mn = 'Business Owner';
		}else{
			var mn = db.getItem('merchantName');
		}
		var temp1 = '<div class="col s12">'+
						'<h6 style="padding:10px;" class="center">Welcome ' + mn + '</h6>'+
					'</div>';*/
		//$('#content-wrapper').parent('div').html(temp1);
		
        var temp = '';
        
		temp+='<div style="margin-top: 20px;-webkit-overflow-scrolling: touch;" data-role="ajax-data-table" reponse-type="json" bottom-distance="100" data-url="" data-page-no="" data-limit="" is-loading="false" callback="vw_dashboardScrollData" data-url-type="GET" data-headers="TRUE">'+	
		 	  '</div>';

        $('#top_loader').show();
        
        // Total Revenue API Call
        temp+='<div style="margin-top: 20px;-webkit-overflow-scrolling: touch;" data-role="ajax-data-table" reponse-type="json" bottom-distance="100" data-url='+little.constants.API.DASHBOARD_YEARLY_REVENUE+' data-page-no="" data-limit="" is-loading="false" callback="vw_dashboardTotalRevenueData" data-url-type="GET" data-headers="TRUE">'+	
		 	  '</div>';
        
        // Monthly Revenue API Call
        temp+='<div style="margin-top: 20px;-webkit-overflow-scrolling: touch;" data-role="ajax-data-table" reponse-type="json" bottom-distance="100" data-url='+little.constants.API.DASHBOARD_MONTHY_REVENUE+' data-page-no="" data-limit="" is-loading="false" callback="vw_dashboardMonthlyRevenueData" data-url-type="GET" data-headers="TRUE">'+	
		 	  '</div>';
        
         // Daily Revenue API Call
        temp+='<div style="margin-top: 20px;-webkit-overflow-scrolling: touch;" data-role="ajax-data-table" reponse-type="json" bottom-distance="100" data-url='+little.constants.API.DASHBOARD_DAILY_REVENUE+' data-page-no="" data-limit="" is-loading="false" callback="vw_dashboardDailyRevenueData" data-url-type="GET" data-headers="TRUE">'+	
		 	  '</div>';
        
        
		$('#content-wrapper').html(temp);
		$('[data-role="lo-pages-head"]').html('Dashboard');
		$('[data-role="ajax-data-table"]').trigger('scroll-data');
        
		$('span.stars').stars();
		resetTabPlacing(1);
	}
	
    little.views.vw_dashboardDailyRevenueData = function(res, obj){
        //console.log(res);
        $('#top_loader').hide();
        var db = getLocalStorage();
        if(db.getItem('merchantName') == undefined || db.getItem('merchantName') == 'undefined'){
			var mn = 'Business Owner';
		}else{
			var mn = db.getItem('merchantName');
		}
        var drr = res.drr;
        var dor = res.dor;
        var dqr = res.dqr;
        if(drr == undefined){
            $( '#daily_revenue_div' ).html('---');    
        }else{
            var i = parseInt(drr);
            console.log("daily - "+(i === parseInt(i, 10)));
            if(i === parseInt(i, 10)){
                $( '#daily_revenue_div' ).html('<span style="font-size:22px; class="WebRupee">&#x20B9;</span><font size="5">'+drr+'</font>'); 
            }else{
                $( '#daily_revenue_div' ).html('<font size="3">'+drr+'</font>'); 
            }
        }
        
        if(dor == undefined){
            $( '#daily_redeem_div' ).html('---');    
        }else{
            $( '#daily_redeem_div' ).html('<font size="5">'+dor+'</font>');    
        }
        
        if(dqr == undefined){
            $( '#daily_qty_div' ).html('---');    
        }else{
            $( '#daily_qty_div' ).html('<font size="5">'+dqr+'</font>');    
        }
        
        $('#content-wrapper').show();
		$('span.stars').stars();
//		
//		resetTabPlacing(1);
    }
    
    var trr, tr, tor, tr_avg, tqr;
    var p, c, r;
    var cmt;
    little.views.vw_dashboardTotalRevenueData = function(res, obj){
//        console.log("vw_dashboardTotalRevenueData");
//        console.log(res);
        $('#top_loader').hide();
        var db = getLocalStorage();
        if(db.getItem('merchantName') == undefined || db.getItem('merchantName') == 'undefined'){
			var mn = 'Business Owner';
		}else{
			var mn = db.getItem('merchantName');
		}
        trr = res.trr;
        tor = res.tor;
        tr = res.tr;
        tqr = res.tqr;
        tr_avg = res.tr_avg;
        p = "phone"
        c = "comment";
        r = "rating";
        cmt = res.cmt;
//        console.log(cmt);
        
        var tr_div = '<p class="col s12 center no-padding">Total Revenue</p>'+
					              '<p class="col s12 center"><span class="WebRupee">&#x20B9;</span>&nbsp;&nbsp;'+trr+'</p>';
//        $( '#tr_div' ).html( $(tr_div));
        $( '#redeemed_div' ).html(tor);
        $( '#votes_div' ).html(tr);
        
        console.log("rating - "+parseInt(tr_avg));
        
        var rating_div = '<div class="col s12" style="font-size: 40px;text-align:left;border-right:1px solid                                            #ccc;color:'+little.constants.RATINGCOLOURARR[Math.ceil(tr_avg)]+'">'+
											'<div class="col s12">'+tr_avg+'</div>'+
											'<div class="col s12">'+
		              							'<span class="stars">'+parseInt(tr_avg)+'</span>'+
		              						'</div>'+
										'</div>';
        $( '#rating_div' ).html(rating_div);
        
        
        if(trr == undefined){
            $( '#yearly_revenue_div' ).html('---');    
        }else{
            var i = parseInt(trr);
            if(i === parseInt(i, 10)){
                $( '#yearly_revenue_div' ).html('<span" style="font-size:22px;" class="WebRupee">&#x20B9;</span><font size="5">'+trr+'</font>'); 
            }else{
                $( '#yearly_revenue_div' ).html('<font size="3">'+trr+'<font>'); 
            }
        }
        
        if(tor == undefined){
            $( '#yearly_redeem_div' ).html('---');    
        }else{
            $( '#yearly_redeem_div' ).html('<font size="5">'+tor+'</font>');    
        }
        
        if(tqr == undefined){
            $( '#yearly_qty_div' ).html('---');    
        }else{
            $( '#yearly_qty_div' ).html('<font size="5">'+tqr+'</font>');    
        }
        
        $('#content-wrapper').show();
		$('span.stars').stars();
//		
//		resetTabPlacing(1);
        
    }
    
    
    little.views.vw_dashboardMonthlyRevenueData = function(res, obj){
//        console.log("vw_dashboardMonthlyRevenueData");
//        console.log(res);
        $('#top_loader').hide();
        var db = getLocalStorage();
        if(db.getItem('merchantName') == undefined || db.getItem('merchantName') == 'undefined'){
			var mn = 'Business Owner';
		}else{
			var mn = db.getItem('merchantName');
		}
        var mrr = res.mrr;
        var mor = res.mor;
        var mqr = res.mqr;
        var mr_div = '<p class="col s12 center no-padding">Monthly Revenue</p>'+
					              '<p class="col s12 center"><span class="WebRupee">&#x20B9;</span>&nbsp;&nbsp;'+mrr+'</p>';
//        $( '#mr_div' ).html( $(mr_div));
        
        if(mrr == undefined){
            $( '#monthly_revenue_div' ).html('---');
        }else{
            var i = parseInt(mrr);
            if(i === parseInt(i, 10)){
                $( '#monthly_revenue_div' ).html('<span style="font-size:22px; class="WebRupee">&#x20B9;</span><font size="5">'+mrr+'</font>');
            }else{
                $( '#monthly_revenue_div' ).html('<font size="3">'+mrr+'</font>');
            }
        }
        
        if(mor == undefined){
            $( '#monthly_redeem_div' ).html('---');     
        }else{
            $( '#monthly_redeem_div' ).html('<font size="5">'+mor+'</font>');    
        }
        
        if(mqr == undefined){
            $( '#monthly_qty_div' ).html('---');     
        }else{
            $( '#monthly_qty_div' ).html('<font size="5">'+mqr+'</font>');    
        }
         
        
        $('#content-wrapper').show();
//		$('span.stars').stars();
//		
//		resetTabPlacing(1);
        
    }
    
    function getDayOfMonthSuffix(n) {
        if (n >= 11 && n <= 13) {
            return "th";
        }
        switch (n % 10) {
            case 1: return "<sup>st</sup>";
            case 2: return "<sup>nd</sup>";
            case 3: return "<sup>rd</sup>";
            default: return "<sup>th</sup>";
        }
    }

    var globalMerchantName = "";
    var globalMerchantCode = "";
	little.views.vw_dashboardScrollData = function(res,obj){
//        console.log("vw_dashboardScrollData");
		//$("div:visible[id*='mNameWrap']").remove();
//		console.log(res);
		var db = getLocalStorage();
		
		if(db.getItem('merchantName') == undefined || db.getItem('merchantName') == 'undefined'){
			var mn = 'Business Owner';
		}else{
			var mn = db.getItem('merchantName');
		}
		
		// var temp1 = '<div id="mNameWrap" class="col s12" style="padding:10px;display:table;width:100%;">'+
						// '<h6 style="color:#777;font-weight:bold;" class="center">Welcome ' + mn + '</h6>'+
					// '<div>';
		// $(temp1).insertBefore('#content-wrapper');
//		var md = res['m'][0];
        var md = "res['m'][0]";
        
        
		var date = new Date();
        var currentMonth = monthNames[date.getMonth()].toUpperCase();
        var currentDay = date.getDay();
        var fullDayString = dayNames[currentDay-1].toUpperCase() + ", " +date.getDate() + getDayOfMonthSuffix(date.getDate()) + 
                            " " + currentMonth;
        
		var temp = '';
        if(isUpdateAvailable() === "true"){
            temp += addUpdateView('update_div', 'updateApp', 0);       
        }
        globalMerchantName = mn;
		temp += '<div id="test1" style="margin-bottom:70px;" class="col s12 no-padding">';
		temp += '<div id="mNameWrap" class="col s12" style="padding:10px;display:table;width:100%;background-color: '+color.grey_light+'">'+
						'<h6 style="color:'+color.grey_dark+';font-weight:bold;" class="center">Welcome ' + mn + '</h6>'+
					'</div>';
        
        // *******************************
        temp+='<div class="row" style="margin-bottom:0px">';
        
        
        
//        temp += '<div class="col s12" style="min-height:165px;margin:0px 0 -70px 0;">'+
//                    '<div class="card" style="background: #ffa726 !important;color: '+color.white+';">'+
//                        '<div class="col s12" style="padding: 0px;margin:0px 0 10px 0;">'+
//                            '<span style="width:100%;display:table;float:left;text-align:center;font-size:20px;padding-top:10px;">THIS YEAR</span>'+
//                        '</div>'+
//            
//                        '<div class="col s12" style="text-align: left;font-size: 1.8rem;">'+
//                            '<div class="row">'+
//                                '<div class="col s6">'+
//                                    '<h4>Revenue</h4>'+
//                                '</div>'+
//                                '<div class="col s6 right-align">'+
//                                    '32656'+
//                                '</div>'+
//                            '</div>'+
//                            '<div class="row">'+
//                                '<div class="col s6">'+
//                                    '<h4>Vouchers</h4>'+
//                                '</div>'+
//                                '<div class="col s6 right-align">'+
//                                    '35'+
//                                '</div>'+
//                            '</div>'+
//                            '<div class="row">'+
//                                '<div class="col s6">'+
//                                    '<h4>Quantity</h4>'+
//                                '</div>'+
//                                '<div class="col s6 right-align">'+
//                                    '3'+
//                                '</div>'+
//                            '</div>'+
//                        '</div>';
//            
////                        '<div class="row">'+
////                            '<div class="card-content white-text" style="text-align:left;">'+
////                                '<div class="col s9" style="color: '+color.white+';font-size:17px;"><nobr>Revenue</nobr></div>'+
////                                '<div class="col s12" style="text-align:right;color: '+color.white+';font-size:17px;"><b>&nbsp;&nbsp;'+'asdasd'+'</b></div>'+
////                                '<div class="col s9" style="color: '+color.white+';font-size:17px;"><nobr>Redeemed</nobr></div>'+
////                                '<div class="col s12" style="text-align:right;color: '+color.white+';font-size:17px;"><b>&nbsp;&nbsp;'+'asdasdas'+'</b></div>'+
////                                '<div class="col s9" style="color: '+color.white+';font-size:17px;"><nobr>Quantity</nobr></div>'+
////                                '<div class="col s12" style="text-align:right;color: '+color.white+';font-size:17px;"><b>&nbsp;&nbsp;'+'adasdasdasd'+'</b></div>'+
////                            '</div>'+
////                        '</div>'+
//                    '</div>'+
//				'</div>'+
//                        '</div>';
        
        temp +='<div class="col s12" style="min-height:165px;margin:0px 0 -70px 0;">'+
			        	'<div class="card" style="background: #ffa726 !important;color: '+color.white+';">'+
			        	//'<div class="card white darken-1">'+
			     			'<div class="col s12" style="padding: 0px;margin:0px 0 10px 0;">'+
			     				// '<span style="background-color:#444D58;color:#fff;width:10%;display:table;float:left;padding: 0 5px">'+
			     					// '<img width="30px;" src="../images/icons/report_icon.png" />'+
			     				// '</span>'+
			     				'<span style="width:100%;display:table;float:left;text-align:center;font-size:20px;padding-top:10px;">THIS YEAR</span>'+
			     			'</div>'+
			     			'<div class="col s12" style="padding:10px;font-size:16px;">'+
			     				'<div class="row">'+
                                    '<div class="col s6">'+
                                        '<h5>Revenue</h5>'+
                                    '</div>'+'<nobr>'+
                                    '<div style="margin-top:10px;margin-right:0px;white-space:normal" id="yearly_revenue_div" class="col s6 right-align">'+
                                        'dasdadssad d asd asdas dasd as'+
                                    '</div>'+
                                '</div>'+
                                '<div class="row">'+
                                    '<div class="col s6">'+
                                        '<h5>Vouchers</h5>'+'<nobr>'+
                                    '</div>'+
                                    '<div style="margin-top:10px;white-space:normal" id="yearly_redeem_div" class="col s6 right-align">'+
                                        ''+
                                    '</div>'+
                                '</div>'+
                                '<div class="row">'+
                                    '<div class="col s6">'+
                                        '<h5>Quantity</h5>'+'<nobr>'+
                                    '</div>'+
                                    '<div style="margin-top:10px;white-space:normal" id="yearly_qty_div" class="col s6 right-align">'+
                                        ''+
                                    '</div>'+
                                '</div>'+
							'</div>'+
							// '<div class="col s12 center" style="font-size:16px;padding:10px 0;">Redeemed</div>'+
						'</div>'+
					'</div>'+
				'</div>'+
            '</div>';
        
        temp+='<div class="row" style="margin-bottom:0px">';
        
         temp +='<div class="col s12" style="min-height:165px;margin:0px 0 0px 0;">'+
			        	'<div class="card" style="background: '+color.blue+' !important;color: '+color.white+';">'+
			        	//'<div class="card white darken-1">'+
			     			'<div class="col s12" style="padding: 0px;margin:0px 0 10px 0;">'+
			     				// '<span style="background-color:#444D58;color:#fff;width:10%;display:table;float:left;padding: 0 5px">'+
			     					// '<img width="30px;" src="../images/icons/report_icon.png" />'+
			     				// '</span>'+
			     				'<span style="width:100%;display:table;float:left;text-align:center;font-size:20px;padding-top:10px;">'+currentMonth+'</span>'+
			     			'</div>'+
             
                            '<div class="col s12" style="padding:10px;font-size:16px;">'+
			     				'<div class="row">'+
                                    '<div class="col s6">'+
                                        '<h5>Revenue</h5>'+
                                    '</div>'+'<nobr>'+
                                    '<div style="margin-top:10px;white-space:normal" id="monthly_revenue_div" class="col s6 right-align">'+
                                        ''+
                                    '</div>'+
                                '</div>'+
                                '<div class="row">'+
                                    '<div class="col s6">'+
                                        '<h5>Vouchers</h5>'+'<nobr>'+
                                    '</div>'+
                                    '<div style="margin-top:10px;white-space:normal" id="monthly_redeem_div" class="col s6 right-align">'+
                                        ''+
                                    '</div>'+
                                '</div>'+
                                '<div class="row">'+
                                    '<div class="col s6">'+
                                        '<h5>Quantity</h5>'+'<nobr>'+
                                    '</div>'+
                                    '<div style="margin-top:10px;white-space:normal" id="monthly_qty_div" class="col s6 right-align">'+
                                        ''+
                                    '</div>'+
                                '</div>'+
							'</div>'+
             
							// '<div class="col s12 center" style="font-size:16px;padding:10px 0;">Redeemed</div>'+
						'</div>'+
					'</div>'+
				'</div>'+
             '</div>';
        
         temp+='<div class="row" style="margin-bottom:0px">';
        
         temp +='<div class="col s12" style="min-height:165px;margin:0px 0 0px 0;">'+
			        	'<div class="card" style="background: '+color.green+' !important;color: '+color.white+';">'+
			        	//'<div class="card white darken-1">'+
			     			'<div class="col s12" style="padding: 0px;margin:0px 0 10px 0;">'+
			     				// '<span style="background-color:#444D58;color:#fff;width:10%;display:table;float:left;padding: 0 5px">'+
			     					// '<img width="30px;" src="../images/icons/report_icon.png" />'+
			     				// '</span>'+
			     				'<span style="width:100%;display:table;float:left;text-align:center;font-size:20px;padding-top:10px;">'+fullDayString+'</span>'+
			     			'</div>'+
             
             
                            '<div class="col s12" style="padding:10px;font-size:16px;">'+
			     				'<div class="row">'+
                                    '<div class="col s6">'+
                                        '<h5>Revenue</h5>'+
                                    '</div>'+'<nobr>'+
                                    '<div style="margin-top:10px;white-space:normal" id="daily_revenue_div" class="col s6 right-align">'+
                                        ''+
                                    '</div>'+
                                '</div>'+
                                '<div class="row">'+
                                    '<div class="col s6">'+
                                        '<h5>Vouchers</h5>'+'<nobr>'+
                                    '</div>'+
                                    '<div style="margin-top:10px;white-space:normal" id="daily_redeem_div" class="col s6 right-align">'+
                                        ''+
                                    '</div>'+
                                '</div>'+
                                '<div class="row">'+
                                    '<div class="col s6">'+
                                        '<h5>Quantity</h5>'+'<nobr>'+
                                    '</div>'+
                                    '<div style="margin-top:10px;white-space:normal" id="daily_qty_div" class="col s6 right-align">'+
                                        ''+
                                    '</div>'+
                                '</div>'+
							'</div>'+
             
							// '<div class="col s12 center" style="font-size:16px;padding:10px 0;">Redeemed</div>'+
						'</div>'+
					'</div>'+
				'</div>'+
             '</div>';
        
        // *******************************
        
        
        
		temp += '<div class="row" style="margin-bottom:0;">'+
//			        '<div class="col s6">'+
//			          '<div class="card white-text" style="padding:20px 10px;background-color:#ffa726">'+
//			          //'<div class="card white-text" style="padding:10px;background-color:#F6A728">'+
//			            '<div class="card-content col s12 no-padding">'+
//            
//            
//            
//					      	'<div class="col s12 no-padding" id="tr_div">'+
//            // Total Revenue
////					              '<p class="col s12 center no-padding">Total Revenue</p>'+
////					              '<p class="col s12 center"><span class="WebRupee">&#x20B9;</span>&nbsp;&nbsp;'+md['trr']+'</p>'+
//					        '</div>'+
//			            '</div>'+
//			      	  '</div>'+
//			      	'</div>'+
//		
				 
//			        '<div class="col s6">'+
//			          '<div class="card white-text text-darken-4" style="padding:20px 10px;background-color:#42a5f5">'+
//			            '<div class="card-content col s12 no-padding">'+
//					      	'<div class="col s12 no-padding" id="mr_div">'+
//            // Monthly Revenue
////					              '<p class="col s12 center no-padding">Monthly Revenue</p>'+
////					              '<p class="col s12 center"><span class="WebRupee">&#x20B9;</span>&nbsp;&nbsp;'+md['cmrr']+'</p>'+
//					        '</div>'+
//			            '</div>'+
//			      	  '</div>'+
//			      	'</div>'+
//			      '</div>'+
			      
			      '<div class="row" style="margin-bottom:0px">'+
			     	// '<div class="col s12">'+
			        	// '<div class="card white darken-1">'+
			     			// '<div class="col s12 white darken-1" style="padding: 0;margin:0px 0 10px 0;">'+
			     				// '<span style="background-color:#444D58;color:#fff;width:10%;display:table;float:left;padding: 0 5px">'+
			     					// '<img width="30px;" src="../images/icons/report_icon.png" />'+
			     				// '</span>'+
			     				// '<span style="width:70%;display:table;float:left;text-align:center;font-size:20px;padding-top:10px;">Sales</span>'+
			     			// '</div>'+
			          		// '<div class="col s6 center">'+
								// '<div id="canvas-holder">'+
									// '<canvas id="chart-area" width="100" height="100"/>'+
								// '</div>'+
								// '<p>Sold</p>'+
							// '</div>'+
							// '<div class="col s12 center">'+
								// '<div id="canves-holder">'+
									// '<canvas id="chart-area" width="150" height="150" />'+
								// '</div>'+
								// '<p>Redeemed</p>'+
							// '</div>'+
						// '</div>'+
					// '</div>'+
//					
//					'<div class="col s12" style="min-height:165px;">'+
//			        	'<div class="card" style="background: #8bc34a !important;color: #fff;">'+
//			        	//'<div class="card white darken-1">'+
//			     			'<div class="col s12" style="padding: 0px;margin:0px 0 10px 0;">'+
//			     				// '<span style="background-color:#444D58;color:#fff;width:10%;display:table;float:left;padding: 0 5px">'+
//			     					// '<img width="30px;" src="../images/icons/report_icon.png" />'+
//			     				// '</span>'+
//			     				'<span style="width:100%;display:table;float:left;text-align:center;font-size:20px;padding-top:10px;">Sales Count</span>'+
//			     			'</div>'+
//			     			'<div class="col s12" style="padding:10px">'+
//			     				'<div class="col s3" style="text-align:left"><i class="fa fa-bar-chart fa-4x"></i></div>'+
//								'<div style="font-size:26px;text-align:right" class="col s9">'+
//									'<div id="redeemed_div" class="col s12">'+'</div>'+
//									'<div class="col s12" style="font-size:17px;">Redeemed</div>'+
//								'</div>'+
//							'</div>'+
//							// '<div class="col s12 center" style="font-size:16px;padding:10px 0;">Redeemed</div>'+
//						'</div>'+
//					'</div>'+
//				'</div>'+
					
		      	'<div class="row" style="margin-bottom:40px;min-height:165px;">'+
		      		'<a class="black-text" style="cursor:pointer;" data-role="nav-item" data-ref="reviews" data-url="" data-callback="vw_reviews" response-type="json">'+
			     		'<div class="col s12">'+
			        		'<div class="card white darken-1">'+
				     			'<div class="col s12 white darken-1" style="padding: 0;margin:0px 0 0px 0;">'+
				     				'<span style="width:100%;display:table;float:left;text-align:center;font-size:20px;padding-top:10px;color:#777;">'+
				     					'<div style="width:90%;float:left">Reviews & Ratings</div>'+
				     					'<div style="width:10%;float:left"><i class="fa fa-angle-right"></i></div>'+
				     				'</span>'+
				     			'</div>'+
				     			'<div class="col s12" style="padding:10px 0">'+
				          			'<div id="rating_div" class="col s6 center">'+
//										'<div class="col s12" style="font-size: 40px;text-align:left;border-right:1px solid #ccc;color:'+little.constants.RATINGCOLOURARR[Math.ceil(md['avgrt'])]+'">'+
//											'<div class="col s12">'+md['avgrt']+'</div>'+
//											'<div class="col s12">'+
//		              							'<span class="stars">'+parseInt(md['avgrt'])+'</span>'+
//		              						'</div>'+
//										'</div>'+
									'</div>'+
									'<div class="col s6">'+
										'<div class="col s12" style="text-align:right">'+
											'<div id="votes_div" style="font-size:32px;color:#777" class="col s12">'+'</div>'+
											'<div style="font-size:20px;" class="col s12">Votes</div>'+
										'</div>'+
									'</div>'+
								'</div>'+
							'</div>'+
						'</div>'+
					'</a>'+
				'</div>';
		temp+='</div>';
		
        if(nwErrorCheck == false){
//            console.log('error false');
            $('#content-wrapper').html(temp).hide();  
            nwErrorCheck = false;
        }else{
            $('#content-wrapper').show();  
        }
//        console.log('first');
		var tis = md['tqtyp'];
		//var cmis = md['cmis'];
		//var cmis = md['cmqtyr'];
		var cmis = md['tqtyr'];
		//initChartJs(tis,cmis);
		
		$('span.stars').stars();
		
		$('[data-role="lo-pages-head"]').html('Dashboard');
		
		resetTabPlacing(1);
//        console.log("vw_dashboardScrollData - end");
	}
	
	
	var oldMenuName;
	little.views.vw_menuScreen = function(data,obj){
        
        $('#top_loader').hide();
        
		if($('[data-role="lo-pages-head"]').html() != 'Menu'){
			oldMenuName = $('[data-role="lo-pages-head"]').html();
		}
		
		
		if($(obj).attr("menu-active") == 'true'){
			if(oldMenuName != 'Dashboard'){
				//$('#mNameWrap').remove();
				$("div:visible[id*='mNameWrap']").remove();
				
				$('[data-role="nav-item"][data-ref="menuScreen"]').attr("menu-active",'false');
			}else{
				//$("div:visible[id*='mNameWrap']").remove();
				var db = getLocalStorage();
				var merchantCode = db.getItem('merchantCode');
				//alert(merchantCode);		
				if(db.getItem('merchantName') == undefined || db.getItem('merchantName') == 'undefined'){
					var mn = 'Business Owner';
				}else{
					var mn = db.getItem('merchantName');
				}
                
				var temp1 = '<div id="mNameWrap" class="col s12" style="padding:10px;display:table;width:100%;overflow:hidden;">'+
						'<h6 style="color:'+color.grey_dark+';font-weight:bold;" class="center">Welcome ' + mn + '<br />('+merchantCode+')</h6>'+
					'<div>';
				$(temp1).html('#menu-wrapper');
				
				$('[data-role="lo-pages-menu"]').hide();
				$('[data-role="lo-pages-head"]').show();
				
				//$('[data-role="menu-bar-wrapper"]').remove();
				$(obj).attr("menu-active",'false');
				
				$('[data-role="lo-pages-head"]').html(oldMenuName);
				$('[data-role="nav-item"][data-ref="menuScreen"]').attr("menu-active",'false');
			}
			
			
			return;
		}
		
		//alert();
		
		$('[data-role="lo-pages-menu"]').show();
		$('[data-role="lo-pages-head"]').hide();
			
        var dw = window.innerWidth
        || document.documentElement.clientWidth
        || document.body.clientWidth;

        // var dh = window.innerHeight
        // || document.documentElement.clientHeight
        // || document.body.clientHeight;
        var dh = $(window).height();
		//alert(dh);
		//$('#mNameWrap').remove();
		//$("div:visible[id*='mNameWrap']").remove();
		var db = getLocalStorage();		
		if(db.getItem('merchantName') == undefined || db.getItem('merchantName') == 'undefined'){
			var mn = 'Business Owner';
		}else{
			var mn = db.getItem('merchantName');
		}
		var merchantCode = db.getItem('merchantCode');
		//alert(merchantCode);
		var temp1 = '<div id="mNameWrap" class="col s12" style="padding:10px;display:table;width:100%;overflow:hidden;">'+
						'<h6 style="color:'+color.grey_dark+';font-weight:bold;" class="center">Welcome ' + mn + '<br />('+merchantCode+')</h6>'+
					'<div>';
		//$(temp1).insertBefore('#menu-wrapper');
		//$(temp1).insertBefore('#content-wrapper');
		//alert($('#mNameWrap').height());
		dh = dh - (($('[data-role="top-nav-bar"]').height()) + $('#mNameWrap').height() + 20);
		//dh = dh - (($('[data-role="top-nav-bar"]').height()) + ($('[data-role="bottom-nav-bar"]').height()) + $('#mNameWrap').height() + 70);
		
		$(obj).attr("menu-active",'true');
		var temp = '';

		temp += '<div data-role="menu-bar-wrapper" style="height: '+dh+'px;width: 100%;background-color:#fff;position:fixed;z-index:1000;margin:0 !important;padding:0 !important;overflow-y:scroll;-webkit-overflow-scrolling: touch;">'+
					'<div style="width:100%">'+
						'<div class="row">'+
							'<div id="mNameWrap" class="col s12" style="padding:10px;display:table;width:100%">'+
								'<h6 style="color:'+color.grey_dark+';font-weight:bold;" class="center">Welcome ' + mn + '<br />('+merchantCode+')</h6>'+
							'<div>'+
						'</div>'+
						'<div class="row">'+
					   		'<ul class="collection" style="border: 0px;">'+
							 	/*'<li class="collection-item" style="padding:20px !important;text-align: center">'+
							 		'<span style="display: table;width:100%;color:#000">'+
							 			temp1+
							 		'</span>'+
							 	'</li>'+*/
            
            
							 	'<li class="collection-item card" style="padding:10px 20px !important;margin:10px;border: 1px solid '+color.light_1+'">'+
							 		'<a id="lDashboard" style="display: table;width:100%;color:#000" data-role="nav-item" data-ref="dashboard" data-url="" data-callback="vw_dashboard" response-type="json" href="#!">'+
							 			//'<span style="display:table-cell;vertical-align: middle;width:10%;"><img style="height: 20px;" src="../images/icons/ic_home.png" /></span>'+
							 			'<span style="display:table-cell;vertical-align: middle;width:10%;"><i style="font-size:24px;" class="fa fa-home grey-text text-darken-2"></i></span>'+
							 			'<span style="display:table-cell;vertical-align:middle;">&nbsp;&nbsp;Home</span>'+
							 			//'<span style="display:table-cell;vertical-align: middle;width:10%;"><img style="height: 30px;" src="../images/icons/arrow.png" /></span>'+
							 			'<i style="font-size:28px;" class="fa fa-angle-right right"></i>'+
							 		'</a>'+
							 	'</li>'+
            
            
            
            
							    '<li class="collection-item card" style="padding:10px 20px !important;margin:10px;border: 1px solid '+color.light_1+'">'+
							    	'<a style="display: table;width:100%;color:#000" data-role="nav-item" data-ref="vw_deals" data-url="" data-callback="vw_deals" response-type="json" response-type="" data-url-type="" data-headers="" href="#!">'+
							    		//'<span style="display:table-cell;vertical-align: middle;width:10%;"><img style="height: 20px;" src="../images/icons/ic_bullhorn.png" /></span>'+
							    		'<span style="display:table-cell;vertical-align: middle;width:10%;"><i style="font-size:24px;" class="fa fa-bullhorn grey-text text-darken-2"></i></span>'+
							    		'<span style="display:table-cell;vertical-align:middle;">&nbsp;&nbsp;Offers</span>'+
							    		//'<span style="display:table-cell;vertical-align: middle;width:10%;"><img style="height: 30px;" src="../images/icons/arrow.png" /></span>'+
							    		'<i style="font-size:28px;" class="fa fa-angle-right right"></i>'+
							    	'</a>'+
							    '</li>'+
							    '<li class="collection-item card" style="padding:10px 20px !important;margin:10px;border: 1px solid '+color.light_1+'">'+
							    	'<a style="display: table;width:100%;color:'+color.black+'" data-role="nav-item" data-ref="paymentHistory" data-url="" data-callback="vw_paymentHistory" response-type="json" href="#!">'+
							    		//'<span style="display:table-cell;vertical-align: middle;width:10%;"><img style="height: 20px;" src="../images/icons/ic_receipt.png" /></span>'+
							    		'<span style="display:table-cell;vertical-align: middle;width:10%;"><i style="font-size:24px;" class="fa fa-list-alt grey-text text-darken-2"></i></span>'+
							    		'<span style="display:table-cell;vertical-align:middle;">&nbsp;&nbsp;Payment history</span>'+
							    		//'<span style="display:table-cell;vertical-align: middle;width:10%;"><img style="height: 30px;" src="../images/icons/arrow.png" /></span>'+
							    		'<i style="font-size:28px;" class="fa fa-angle-right right"></i>'+
							    	'</a>'+
							    '</li>'+
							    '<li class="collection-item card" style="padding:10px 20px !important;margin:10px;border: 1px solid '+color.light_1+'">'+
							    	'<a style="display: table;width:100%;color:#000" data-role="nav-item" data-ref="reviews" data-url="" data-callback="vw_reviews" response-type="json" href="#!">'+
							    		//'<span style="display:table-cell;vertical-align: middle;width:10%;"><img style="height: 20px;" src="../images/icons/ic_heart.png" /></span>'+
							    		'<span style="display:table-cell;vertical-align: middle;width:10%;"><i style="font-size:24px;" class="fa fa-heart grey-text text-darken-2"></i></span>'+
							    		'<span style="display:table-cell;vertical-align:middle;">&nbsp;&nbsp;Ratings &amp; Reviews</span>'+
							    		//'<span style="display:table-cell;vertical-align: middle;width:10%;"><img style="height: 30px;" src="../images/icons/arrow.png" /></span>'+
							    		'<i style="font-size:28px;" class="fa fa-angle-right right"></i>'+
							    	'</a>'+
							    '</li>'+
							    '<li class="collection-item card" style="padding:10px 20px !important;margin:10px;border: 1px solid #e0e0e0">'+
							    	'<a style="display: table;width:100%;color:'+color.black+'" data-role="nav-item" data-ref="redemption" data-url="" data-callback="vw_redemption" response-type="json" href="#!">'+
							    		//'<span style="display:table-cell;vertical-align: middle;width:10%;"><img style="height: 20px;" src="../images/icons/ic_wallet_giftcard.png" /></span>'+
							    		'<span style="display:table-cell;vertical-align: middle;width:10%;"><i style="font-size:24px;" class="fa fa-gift grey-text text-darken-2"></i></span>'+
							    		'<span style="display:table-cell;vertical-align:middle;">&nbsp;&nbsp;Voucher Redemption</span>'+
							    		//'<span style="display:table-cell;vertical-align: middle;width:10%;"><img style="height: 30px;" src="../images/icons/arrow.png" /></span>'+
							    		'<i style="font-size:28px;" class="fa fa-angle-right right"></i>'+
							    	'</a>'+
							    '</li>'+
							    '<li class="collection-item card" style="padding:10px 20px !important;margin:10px;border: 1px solid '+color.light_1+'">'+
//            
//            '<div style="margin-top: 20px;-webkit-overflow-scrolling: touch;" data-role="ajax-data-table" reponse-type="json" bottom-distance="100" data-url="" data-page-no="" data-limit="" is-loading="false" callback="vw_dashboardScrollData" data-url-type="GET" data-headers="TRUE">'+	
//		 	  '</div>'+
          
							    	'<a style="display: table;width:100%;color:'+color.black+'" data-role="nav-item" data-ref="contact" data-url='+little.constants.API.DASHBOARD_CONTACT+' data-callback="vw_contact" data-url-type="GET" data-headers="TRUE" response-type="json"  href="#!">'+
							    		//'<span style="display:table-cell;vertical-align: middle;width:10%;"><img style="height: 20px;" src="../images/icons/ic_contact.png" /></span>'+
							    		'<span style="display:table-cell;vertical-align: middle;width:10%;"><i style="font-size:24px;" class="fa fa-phone-square grey-text text-darken-2"></i></span>'+
							    		'<span style="display:table-cell;vertical-align:middle;">&nbsp;&nbsp;Contact Little</span>'+
							    		//'<span style="display:table-cell;vertical-align: middle;width:10%;"><img style="height: 30px;" src="../images/icons/arrow.png" /></span>'+
							    		'<i style="font-size:28px;" class="fa fa-angle-right right"></i>'+
							    	'</a>'+
							    '</li>'+
							    '<li class="collection-item card" style="padding:10px 20px !important;margin:10px;border: 1px solid '+color.light_1+'">'+
							    	'<a style="display: table;width:100%;color:'+color.black+'" data-role="nav-item" data-ref="contact" data-url="" data-callback="vw_version" response-type="json" href="#!">'+
							    		//'<span style="display:table-cell;vertical-align: middle;width:10%;"><img style="height: 20px;" src="../images/icons/ic_info.png" /></span>'+
							    		'<span style="display:table-cell;vertical-align: middle;width:10%;"><i style="font-size:24px;" class="fa fa-info-circle grey-text text-darken-2"></i></span>'+
							    		'<span style="display:table-cell;vertical-align:middle;">&nbsp;&nbsp;About</span>'+
							    		//'<span style="display:table-cell;vertical-align: middle;width:10%;"><img style="height: 30px;" src="../images/icons/arrow.png" /></span>'+
							    		'<i style="font-size:28px;" class="fa fa-angle-right right"></i>'+
							    	'</a>'+
							    '</li>'+
							    '<li class="collection-item card" style="padding:10px 20px !important;margin:10px;border: 1px solid '+color.light_1+'">'+
							    	'<a style="display: table;width:100%;color:#000" onclick="logout();">'+
							    		//'<span style="display:table-cell;vertical-align: middle;width:10%;"><img style="height: 20px;" src="../images/icons/ic_power.png" /></span>'+
							    		'<span style="display:table-cell;vertical-align: middle;width:10%;"><i style="font-size:24px;" class="fa fa-power-off grey-text text-darken-2"></i></span>'+
							    		'<span style="display:table-cell;vertical-align:middle;">&nbsp;&nbsp;Logout</span>'+
							    		//'<span style="display:table-cell;vertical-align: middle;width:10%;"><img style="height: 30px;" src="../images/icons/arrow.png" /></span>'+
							    		'<i style="font-size:28px;" class="fa fa-angle-right right"></i>'+
							    	'</a>'+
							    '</li>'+
							 '</ul>'+
					    '</div>'+
					'</div>'+
				'</div>';
		$('#menu-wrapper').prepend(temp);
		//$('[data-role="menu-bar-wrapper"]').animate({ marginLeft: "100%"} , 4000);
		//$('[data-role="menu-bar-wrapper"]').show();
		//$('[data-role="menu-bar-wrapper"]').fadeIn();
		//$('[data-role="menu-bar-wrapper"]').animate({left:0, opacity:"show"}, 300);;
		//$('[data-role="menu-bar-wrapper"]').show();
		//$('[data-role="menu-bar-wrapper"]').show('slide',{direction:'right'},10000);
		$('[data-role="lo-pages-head"]').html('Menu');
	}
	
	
	little.views.vw_contact = function(res){
		//$('#mNameWrap').remove();
//        console.log(res);
		$("div:visible[id*='mNameWrap']").remove();
		
		userHistory[userHistory.length] = 'vw_contact';
//		var db = getLocalStorage();
		var contactName = res.am;
		var contactPhone = res.cc;
		var contactEmail = res.e;
//		console.log(contactName);
//        console.log(contactPhone);
//        console.log(contactEmail);
		
//		var db = getLocalStorage();
//		var bdeInfo = JSON.parse(db.getItem('bdeInfo'));
//		
		
		var temp = '';
		temp += '<div style="background-color:'+color.white_1+';margin-top: 20px;">'+
					'<div class="row" style="margin-bottom:0px !important;padding-botton:0 !important;">'+
				   		'<div class="col s12">'+
					   		'<div class="card">'+
						   		'<div class="col s12 card-action" style="display:none;">'+
						   			
//						   			'<p class="col s12">'+
//							   			'<span class="left" style="display:table;"><img style="height: 20px;" src="../images/icons/cn.png" /></span>'+
//							   			'<span class="left" style="display:table;">&nbsp;&nbsp;&nbsp;&nbsp;Manager name</span>'+
//							   		'</p>'+
//						        	
//						        	'<div class="col s12 divider grey lighten-1"></div>'+
//						   			'<p class="col s12">'+contactName+'</p>'+
						          	
						          	'<p class="col s12">'+
						          		'<span class="left" style="display:table;"><img style="height: 20px;" src="../images/icons/cp.png" /></span>'+
						          		'<span class="left" style="display:table;">&nbsp;&nbsp;&nbsp;&nbsp;Contact number</span>'+
						          	'</p>'+
						        	
						        	'<div class="col s12 divider grey lighten-1"></div>'+
						   			'<p class="col s12"><a class="blue-text text-darken-3" href="tel:'+contactPhone+'">'+contactPhone+""+'</a></p>'+
						          	
						          	'<p class="col s12">'+
						          		'<span class="left" style="display:table;"><img style="height: 20px;" src="../images/icons/ce.png" /></span>'+
						          		'<span class="left" style="display:table;">&nbsp;&nbsp;&nbsp;&nbsp;Email</span>'+
						          	'</p>'+
						          	
						          	'<div class="col s12 divider grey lighten-1"></div>'+
						   			'<p class="col s12"><a class="blue-text text-darken-3" href="mailto:'+contactEmail+'">'+contactEmail+""+'</a></p>'+
						        '</div>'+
						        
						        '<div class="col s12 card-action">'+
						   			
						          	'<p class="col s12">'+
						          		'<span class="left" style="display:table;"><img style="height: 20px;" src="../images/icons/ce.png" /></span>'+
						          		'<span class="left" style="display:table;">&nbsp;&nbsp;&nbsp;&nbsp;Email Us</span>'+
						          	'</p>'+
						          	
						          	'<div class="col s12 divider grey lighten-1"></div>'+
						   			'<p class="col s12"><a class="blue-text text-darken-3" href="mailto:'+contactEmail+'">'+contactEmail+'</a></p>'+
						        '</div>'+
							'</div>'+
					    '</div>'+
					'</div>'+
				    '<div style="margin-top:30px" class="divider"></div>'+
					'<span style="text-align: center;width: 100%;display: table;position: relative;bottom: 14px;font-size:18px;">OR</span>'+
					
					'<div class="row">'+
						'<div class="col s12">'+
							'<div class="card">'+
						   		'<div class="col s12 card-action">'+
						          	
						          	'<p class="col s12">'+
						          		'<span class="left" style="display:table;"><img style="height: 20px;" src="../images/icons/cp.png" /></span>'+
						          		'<span class="left" style="display:table;">&nbsp;&nbsp;&nbsp;&nbsp;Call our customer care</span>'+
						          	'</p>'+
						        	
						        	'<div class="col s12 divider grey lighten-1"></div>'+
						   			'<p class="col s12"><a class="blue-text text-darken-3" href="tel:'+contactPhone+'">'+contactPhone+'</a></p>'+
						   			//'<p class="col s12"><a class="blue-text text-darken-3" onClick="app.openNativeAppWindow(\'tel:2125551212\')">08046724672</a></p>'+	
						        '</div>'+
					    	'</div>'+
					    '</div>'+
				    '</div>';
				
//				    if(bdeInfo != null && bdeInfo.length > 0){
					    temp += '<div style="margin-top:30px" class="divider"></div>'+
								'<span style="text-align: center;width: 100%;display: table;position: relative;bottom: 14px;font-size:18px;">OR</span>'+
								
								'<div class="row">'+
									'<div class="col s12">'+
										'<div class="card">'+
									   		'<div class="col s12 card-action">'+
									          	
									          	'<p class="col s12">'+
									          		'<span class="left" style="display:table;"><img style="height: 20px;" src="../images/icons/ic_info.png" /></span>'+
									          		'<span class="left" style="display:table;">&nbsp;&nbsp;&nbsp;&nbsp;Account Manager</span>'+
									          	'</p>'+
									        	
									        	'<div class="col s12 divider grey lighten-1"></div>';
									        	
//									        	for(var i=0;i<bdeInfo.length;i++){
									   				temp += '<p class="col s12"><a class="blue-text text-darken-3" href="tel:'+contactName+'">'+contactName + '</a></p>';
//									        	}
					
									   				
									        temp += '</div>'+
								    	'</div>'+
								    '</div>'+
							    '</div>';
//					}
				    
						    /*'<div style="margin-top:30px" class="divider"></div>'+
							'<span style="text-align: center;width: 100%;display: table;position: relative;bottom: 14px;font-size:18px;">OR</span>'+
							
							'<div class="row">'+
								'<div class="col s12">'+
									'<div class="card">'+
								   		'<div class="col s12 card-action">'+
								          	
								          	'<p class="col s12">'+
								          		'<span class="left" style="display:table;"><img style="height: 20px;" src="../images/icons/cp.png" /></span>'+
								          		'<span class="left" style="display:table;">&nbsp;&nbsp;&nbsp;&nbsp;Request a callback</span>'+
								          	'</p>'+
								        	
								        	'<div class="col s12 divider grey lighten-1"></div>'+
								   			'<a data-role="nav-item" data-ref="dashboard" data-url='+little.constants.API.CALLBACK+' data-callback="vw_callback" response-type="json" href="#!"  class="col s12 btn white-text" style="background-color:#5a0f5a">Request</a>'+
								          	
								        '</div>'+
								    '</div>'+
							    '</div>'+
						    '</div>'+*/
						temp += '</div>';
		$('#content-wrapper').html(temp);
		$('[data-role="lo-pages-head"]').html('Contact');
		$('[data-role="nav-item"][data-ref="menuScreen"]').attr("menu-active",'false');
	}
	
	/*var app = {
	        initialize: function() {
		        this.bindEvents();
		    },         
		    bindEvents: function() {
		        document.addEventListener('deviceready', this.onDeviceReady, false);
		    },         
		    onDeviceReady: function() {
		        app.receivedEvent('deviceready');
		    },
		    openNativeAppWindow: function(data) {
		        window.open(data, '_system');
		    }
	  	};*/
	
	
	little.views.vw_callback = function(res){
		Materialize.toast(res.dm, 4000,'center')
	}
	
	
	little.views.vw_version = function(res){
		//$('#mNameWrap').remove();
		$("div:visible[id*='mNameWrap']").remove();
		
		userHistory[userHistory.length] = 'vw_version';
		var temp = '';
		temp += '<div class="row" style="margin:20px 8px;">'+
			   		'<div class="col s12 card">'+
				   		'<div class="col s12 card-action center">'+
				   			'<h5 style="display:table;">'+
				   				'<img style="float:left;height: 40px;margin: 10px 0 0px 10px;" src="../images/icons/lil-merchant60x60.png" />'+
				   				'<span style="display:table;;float:left;padding:20px 0 0 10px">Dashboard</span>'+
				   			'</h5>'+
				   			'<p class="col s12">'+
					   			'<h6 class="blue-text text-darken-4">App Version: '+appVersion+'</h6>'+
					   		'</p>'+
				   			'<p>11th KM, BPL Campus, Bannerghatta Road, Arekare,Bangalore 560076</p>'+
				        '</div>'+
					'</div>'+
			    '</div>';
		$('#content-wrapper').html(temp);
		$('[data-role="lo-pages-head"]').html('About');
		$('[data-role="nav-item"][data-ref="menuScreen"]').attr("menu-active",'false');
	}
	
	little.views.vw_deals = function(res){
		//alert(1);
		userHistory[userHistory.length] = 'vw_deals';
		var temp = '';
		temp+='<div style="margin-top: 20px;" data-role="ajax-data-table" reponse-type="json" bottom-distance="100" data-url='+little.constants.API.DASHBOARD_OFFERS+' data-page-no="" data-limit="" is-loading="false" callback="vw_dealsScrollData" data-url-type="GET" data-headers="TRUE">'+	
		
		 	  '</div>';
		$('#content-wrapper').html(temp);
		$('[data-role="lo-pages-head"]').html('Offers');
		$('[data-role="ajax-data-table"]').trigger('scroll-data');
		//alert(2);
	}
	
	little.views.vw_dealsScrollData = function(res,obj){
		//alert(3);
//		console.log(res);
		var m = res;
		var temp = '';
		temp+='<div style="background-color:#EFF3F8;margin-bottom:40px;">';
			var dealStatus = '';
			var dealStatusText = 'In Active';
			var dealStatusColor = '#b71c1c';
			//for()
			if(m.length == 0){
					temp += '<div class="row">'+
						    	'<div class="col s12">'+
						        	'<div class="card center">'+
						           		'<div class="card-content gray-text col s12" style="text-align:center">'+
						              		'<div class="col s12"><h6>No Record Found</nobr></h6>'+
						            	'</div>'+
						          	'</div>'+
						        '</div>'+
						      '</div>';
				temp+='</div>';
					$(obj).append(temp);
					resetTabPlacing(2);
					return;
			}
			
			$.each(m,function(dIndex,deal){
				//console.log(deal);
				//alert(4);
					if(deal.s == 'active'){
						dealStatus = 'checked="checked"';
						dealStatusText = 'ACTIVE';
						dealStatusColor = color.green_dark;
					}else{
						var dealStatus = '';
						var dealStatusText = 'INACTIVE';
						var dealStatusColor = color.red;
					}
					
					//alert(deal.sts);
					//alert(deal.dn);
					//alert(deal.sst);
					//var test1 = (deal.sst).sectodate('d M Y'); 
					//alert(test1);
					//alert((deal.sdt).sectodate('d M Y'));
					//alert(deal.tis);
					//alert(deal.tiu);
					//alert(10);
                
//                console.log(deal.dsd);
                var sd = new Date(parseFloat(deal.dsd*1000));
                var finalSdString = monthNames[sd.getMonth()] + ", " + sd.getFullYear() + " " + sd.getHours() + ":" +sd.getMinutes() + ":" + sd.getSeconds();
                var ed = new Date(parseFloat(deal.ded*1000));
                var finalEdString = monthNames[ed.getMonth()] + ", " + ed.getFullYear() + " " + ed.getHours() + ":" +ed.getMinutes() + ":" + ed.getSeconds();
                
					temp += '<div class="row">'+
						        '<div class="col s12">'+
						          '<div class="card">'+
//                        '<div style="padding:5px;margin-left:15px;margin-bottom:-15px;margin-top:5px;"><b>'+""+'Vouchers Redeemed ('+deal.r+'</b>)</div>'+
//						          	'<div class="col s12 no-padding center">'+      	
//										'<div class="col s2 white-text" style="background-color:'+dealStatusColor+';float:left;padding:5px;">'+
//										    '<span style="padding:0px;">'+dealStatusText+'</span>'+
//										'</div>'+
//										'<div class="col s10 blue-grey-text text-darken-1" style="padding:5px;font-size:17px;">'+""+'</div>'+
//							        '</div>'+ 
						            // '<div class="card-content" style="padding-bottom: 10px">'+
						            '<div class="card-content" style="padding-bottom: 10px;margin-top:0px;">'+
//						              '<p>'+
//						            	'&nbsp;<i style="font-size:18px;" class="fa fa-map-marker"></i>&nbsp;&nbsp;&nbsp;&nbsp;'+
//						              	deal.ad+
//						              '</p>'+
						              '<p>'+
					              		deal.dn+
                        " " + '&nbsp;<span style="color:'+dealStatusColor+'"><b>('+dealStatusText+')</b></span>' +
						              '</p>'+
                        '<p style="font-size:14px; color:'+color.grey_dark_2+'">Valid from <b class="ng-binding">'+finalSdString+'</b> to <b class="ng-binding">'+finalEdString+'</b></p>'+
						            '</div>'+
                        
					              	'<div class=" col s12" style="margin-left:10px;">'+
                        
//                                         '<p style="font-size:14px; color:#666">Valid from <b class="ng-binding">'+(deal.dsd*1000).sectodate('d M Y')+'</b> to <b class="ng-binding">'+(deal.ded*1000).sectodate('d M Y')+'</b></p>'+
                        
                        
//						              '<p class="col s6" style="margin:0">'+
//						              '<span class="col s12 no-padding">Valid From '+(deal.dsd*1000).sectodate('d M Y')+' to '+ (deal.ded*1000).sectodate('d M Y')+'</span>'+
//						              		'<span class="col s12 no-padding">'+(deal.dsd*1000).sectodate('d M Y')
//                                            +' to '+ (deal.ded*1000).sectodate('d M Y') 
//                                            +'</span>'+
//						              	
//						              '</p>'+
//						              
//						              '<p class="col s6" style="margin:0">'+
//						              		'<span class="col s12 no-padding">Valid Till</span>'+
//						              		'<span class="col s12 no-padding">'+(deal.ded*1000).sectodate('d M Y')+'</span>'+
//						              	
//						              '</p>'+
						          	'</div>'+
//						            '<div class="card-action col s12 grey lighten-2" style="padding:5px 0">'+
//						              	// '<div class="col s6 center">'+
//						              		// '<a class="subdued ng-binding white-text">'+
//										    	// 'Sold'+
//										    	// '&nbsp;:&nbsp;&nbsp;'+deal.tis+
//											// '</a>'+
//						              	// '</div>'+
//						              	// '<div class="col s6 center">'+
//						              		// '<a class="subdued ng-binding white-text">'+
//										    	// 'Used'+
//										    	// '&nbsp;:&nbsp;&nbsp;'+deal.tiu+
//											// '</a>'+
//						              	// '</div>'+
//						              	'<div class="col s12">'+
//						              		'<a class="subdued ng-binding grey-text text-darken-3">'+
//										    	'Redeemed'+
//										    	'&nbsp;:&nbsp;&nbsp;'+deal.r+
//											'</a>'+
//						              	'</div>'+
//						            '</div>'+
						      	  '</div>'+
						      	'</div>'+
						      '</div>';
						      //alert(15);
			});
			//alert(5);
			temp+='</div>';
			//alert(temp);
			//alert("hi");
		$(obj).append(temp);
		
		resetTabPlacing(2);
	}
	
	
	little.views.vw_orders = function(res){
		userHistory[userHistory.length] = 'vw_orders';
		var temp = '';
		temp+='<div style="margin-top: 20px;" data-role="ajax-data-table" reponse-type="json" bottom-distance="100" data-url="https://nvy.com/api/dashboard/merchant/mc-0095009" data-page-no="" data-limit="" is-loading="false" callback="vw_ordersScrollData" data-url-type="GET" data-headers="TRUE">'+	
		
		 	  '</div>';
		$('#content-wrapper').html(temp);
		$('[data-role="lo-pages-head"]').html('Orders');
		$('[data-role="ajax-data-table"]').trigger('scroll-data');
	}
	
	little.views.vw_ordersScrollData = function(res,obj){
		var m = res['m'];
		var mCnt = res['m'].length;
		var d = res['m'][0]['deals'];
		var dCnt = res['m'][0]['deals'].length;
		var o = res['m'][0]['deals'][0]['o'];
		var oCnt = res['m'][0]['deals'][0]['o'].length;
		var temp = '';
		$.each(m,function(mIndex,merchant){
			$.each(merchant.deals,function(dIndex,deal){
				$.each(deal.o,function(oIndex,order){
					var od = (order.rdt*1000).sectodate('d M Y');
					
					
					temp += '<div class="row">'+
						        '<div class="col s12">'+
						          '<div class="card">'+
						            '<div class="card-content">'+
							            '<div class="col s12 no-padding">'+
							              	'<span class="card-title  blue-grey-text text-darken-1 col s9 no-padding">'+order.aoc+'</span>'+
							              	'<span style="line-height:48px;" class="blue-grey-text text-darken-1 col s3 no-padding">'+od+'</span>'+
						              	'</div>'+
						              '<p>'+merchant.mn+'</p>'+
						              '<p>'+deal.dn+'</p>'+
						            '</div>'+
						      	  '</div>'+
						      	'</div>'+
						      '</div>';	
				});	
			});
		});
		$(obj).append(temp);
	}
	
	little.views.vw_paymentHistory = function(res){
		//console.log(res);
		userHistory[userHistory.length] = 'vw_paymentHistory';
		var temp = '';
		
		temp+='<div style="margin-top: 20px;" data-role="ajax-data-table" reponse-type="json" bottom-distance="100" data-url='+little.constants.API.DASHBOARD_PAYMENT+' data-page-no="" data-limit="" is-loading="false" callback="vw_paymentHistoryScrollData" data-url-type="GET" data-headers="TRUE">'+	
		
		 	  '</div>';
		
		$('#content-wrapper').html(temp);
		$('[data-role="lo-pages-head"]').html('Payment History');
		$('[data-role="ajax-data-table"]').trigger('scroll-data');
	}
	var p_keys = [];
	little.views.vw_paymentHistoryScrollData = function(res,obj){
//		console.log(res);
//        console.log(res.trr);
        var paymentV2 = res['p'];
//        console.log(paymentV2[0].url);
        p_keys = [];
//        console.log(Object.keys(paymentV2).length);
        var j = 0;
        Object.keys(paymentV2).forEach(function(key) {
            p_keys[j] = key;
//            console.log("json - "+key);
//            console.log("arr - "+p_keys[j]);
           
//            console.log("Servuce tax " + paymentV2[p_keys[j]]["tst"]);
             j++;
        });
        j = 0;
        
//        var paymentHistory = res['m']['p']; 
		var cnt = Object.keys(paymentV2).length;
		var totalPayment = res.tap;
        
//		var paymentHistory = res['m']['p']; 
//		var cnt = paymentHistory.length;
//		var totalPayment = res['m']['tap'];
		
		var temp = '';
		temp+='<div style="padding-bottom: 10px;margin-bottom:10px">';
		if(!(res.p)){
			temp += '<div class="row">'+
				    	'<div class="col s12">'+
				        	'<div class="card center">'+
				           		'<div class="card-content gray-text col s12" style="text-align:center">'+
				              		'<div class="col s12"><h6>No Record Found</nobr></h6>'+
				            	'</div>'+
				          	'</div>'+
				        '</div>'+
				      '</div>';
		}else{
		
//			temp += '<div class="row">'+
//				    	'<div class="col s12">'+
//				        	'<div class="card">'+
//				        		'<div class="col s12 card-title  grey lighten-2 grey-text text-darken-3" style="padding:5px;font-size:14px;">'+
//									'Summary'+
//								'</div>'+
//				           		'<div class="card-content black-text col s12" style="text-align:left">'+
//				              		'<div class="col s6"><nobr>Total Amount Disbursed :</nobr></div>'+
//				              		'<div class="col s6" style="text-align:right"><b>&nbsp;&nbsp;'+totalPayment+'</b></div>'+
//				              		'<div class="col s6"><nobr>Total Due Amount :</nobr></div>'+
//				              		'<div class="col s6" style="text-align:right"><b>&nbsp;&nbsp;'+res.trr+'</b></div>'+
//				              		'<div class="col s6"><nobr>Total Commision :</nobr></div>'+
//				              		'<div class="col s6" style="text-align:right"><b>&nbsp;&nbsp;'+res.tcommr+'</b></div>'+
//				              		'<div class="col s6"><nobr>Net Payable Amount :</nobr></div>'+
//				              		'<div class="col s6" style="text-align:right"><b>&nbsp;&nbsp;'+res.npa+'</b></div>'+
//				            	'</div>'+
//				          	'</div>'+
//				        '</div>'+
//				     '</div>';
			temp +=  '<div class="row">';
			for(var i=0;i<cnt;i++){
                var kk = p_keys[i];
//                console.log("print - "+paymentV2[i].t);
//                console.log(paymentV2[p_keys[i]]);
//				var p_date = ((paymentV2[p_keys[i]]["pd"]*1000).sectodate('d M Y'));
                var pd = new Date(parseFloat(paymentV2[p_keys[i]]["pd"]*1000));
                var finalPdString = monthNames[pd.getMonth()] + ", " + pd.getFullYear() + " " + pd.getHours() + ":" +pd.getMinutes() + ":" + pd.getSeconds();
                var verticalDivider;
                if(i === cnt-1){
                    verticalDivider = '';
                }else{
                    verticalDivider = '<div class="divider" style="height: 30px !important;width: 2px !important;margin:0 auto;"></div>';
                }
                
				temp += '<div class="col s12" data-value = "paymentHistoryCardWrap" style="margin-bottom: 20px;">'+
							'<div class="col s12">'+
								'<div class="col s1 center no-padding">'+
									'<span class="col s12 no-padding">'+
										'<img width="100%" src="../images/icons/tick.png" />'+
									'</span>'+
									verticalDivider+
								'</div>'+
								'<div class="col s11 no-padding">'+
									'<div class="col s12">'+
										'<div class="card" style="margin-top:0;margin-bottom:0">'+
                      '<div class="col s12 no-padding">'
                   +
                    '<a style="cursor:pointer;display:table;padding:10px;"  data-role="payment-details" data-value="'+paymentV2[i].url+'">'+paymentV2[i].t+'</a>' +'</div>'+
							            	'<div class="card-content grey-text text-darken-2">'+
												'<div class="card-content col s12 no-padding">'+ 
											        '<div class="col s12 no-padding">'
											            ;
//											            '<div class="col s12 no-padding">Due&nbsp;&nbsp;<span class="WebRupee">&#x20B9;</span>&nbsp;'+paymentV2[p_keys[i]]["tad"]+'</div>'+
//											            '<div class="col s12 no-padding">Paid&nbsp;&nbsp;<span class="WebRupee">&#x20B9;</span>&nbsp;'+paymentV2[p_keys[i]]["tap"]+'</div>';
//											            if(paymentHistory[i]['adv']>0){
//											            	temp += '<div class="col s12 no-padding">Advance&nbsp;&nbsp;<span class="WebRupee">&#x20B9;</span>&nbsp;'+paymentHistory[i]['adv']+'</div>';
//											            }
											            temp += ''+
											            //'<div class="col s12 no-padding">Commission&nbsp;&nbsp;<span class="WebRupee">&#x20B9;</span>&nbsp;'+paymentHistory[i]['com']+'</div>'+
											            // '<div class="col s12 no-padding">'+
											            //'<div class="col s12 card-action no-padding">'+
//											            '<div class="col s12 card-action no-padding">'+
//											            	'<a style="cursor:pointer;display:table;padding:10px;width:100%"  data-role="payment-details" data-value="'+p_keys[i]+'">'+
//											            		'<span>UTR&nbsp;&nbsp;'+p_keys[i]+'</span>'+
//											            		'<i class="fa fa-angle-right fa-2x right"></i>'+
//											            	'</a>'+
//											            '</div>'+
											            	//'<a style="cursor:pointer;display:table;padding:10px;width:100%" data-role="payment-details" data-value="'+paymentHistory[i]['utr']+'">UTR&nbsp;&nbsp;'+paymentHistory[i]['utr']+'</a>'+
											            //'</div>'+
											        '</div>'+ 
											   '</div>'+ 
											'</div>'+
										'</div>'+
									'</div>'+
								'</div>'+
							'</div>'+
						'</div>';
			}
			temp+='</div>';
		}
		temp+='</div>';
		$(obj).append(temp);
		
		resetTabPlacing(4);
	}
	
    
	$(document).on('click','a[data-role="payment-details"]',function(){

		userHistory[userHistory.length] = 'a[data-role="payment-details"]';
//		$(this).append('<p class="center"><i data-role="loader" style="font-size:18px;padding:10px 0 0 0;" class="fa fa-spin fa-spinner"></></p>');
        
        
		var obj = this;
		//return;
		var utr = $(this).attr('data-value');
        
        intel.xdk.device.launchExternal(utr);
        
        
        
//        intel.xdk.device.copyToClipboard(utr);
//        $('.body').html('<div>Hello World!</div>');
//        intel.xdk.device.launchExternal(utr);
//       intel.xdk.device.showRemoteSiteExt(utr, positionx,0,positionx,0,50,50);
//        intel.xdk.device.showRemoteSiteExt(utr, 280,0,50,50,60,60);
		//alert(utr);
		//alert("hi");return;
		
		//var u = 'https://nvy.com/api/dashboard/merchant?q={"t":"putr","utr":"'+utr+'"}';
//		var u = 'https://nvy.com/api/dashboard/merchant?q={"t":"mputr","utr":"'+utr+'"}';
//        var u = config.data.payments.utr_code + utr;
		//var u = "https://nvy.com/"
	    //u += 'api/dashboard/merchant?q={"t":"putr","utr":'+utr+'}';
		    
//		    
//		var db = getLocalStorage();
//		var merchantCode = db.getItem('merchantCode');
//		
//		var apiKey = db.getItem('apiKey');
//		var publicKey = db.getItem('publicKey');
//		var passhash = CryptoJS.MD5(apiKey+publicKey);
//		
//		//alert(u);
//		//alert(merchantCode);
//		//alert(passhash);
//		var headers = {
//			//VALUES : {'t':token,'p':'+919845035265','k':password},
//			VALUES : {'t':passhash,'p': merchantCode},
//		}
//	
		//var data = {"who": { "p": "+919845035265" },"o": {"mc": merchantCode,"aoc": couponCode}};
//		$.ajax({
//			url: u,
//			type: 'GET',
//			dataType: 'json',
//			contentType: 'application/json',
//			beforeSend: function(xhr) {
//				$.each(headers.VALUES,function(index,value){
//					xhr.setRequestHeader(index,value);	
//				});
//			},
//			error: function (request, status, error) {
//				var data = $.parseJSON(request.responseText);
////				console.log(data);
//				$('[data-role="loader"]').remove();
//				var temp = '';
//				temp += '<div class="col s12" style="padding-bottom:10px;">'+
//							'<div class="card" style="margin: 10px 0;padding: 0 0 10px 0;">'+
//								'<p class="center" style="color:#b71c1c">'+
//									data['dm'] +
//								'</p>'+
//							'</div>'+
//						'</div>';
//				$(obj).closest('[data-value = "paymentHistoryCardWrap"]').after(temp);
//			},
//			success: function(res){
////				console.log(res[0]);
//				//var data = $.parseJSON(res);
//				//console.log(res);
//				var data = res;
//				var len = res.length;
//				var temp = '';
//				//var i=0;
//				temp += '<div style="margin-top: 20px;">';
//				for(var i=0;i<len;i++){
//					temp += '<div class="col s12" style="padding-bottom:10px;">'+
//								'<div class="card" style="margin: 10px;padding: 0 0 10px 0;">'+
//									'<div class="row" style="padding:10px 0 0 0;margin-bottom:0px;background-color:#546E7A">'+
//										'<div class="col s2 center" style="color:#ffffff;margin-bottom:5px;">#'+ (i+1) +'</div>'+
////										'<div class="col s5 center" style="border-right:1px solid #e0e0e0"><i class="fa fa-rupee"></i>&nbsp;'+'</div>'+
////										'<div class="col s5 center">#'+'</div>'+
//									'</div>'+
//									'<div class="divider"></div>'+
//					            	'<div class="card-content grey-text text-darken-2" style="padding:10px">'+								        
//										'<p>'+
//											'&nbsp;'+"Coupon Code  "+
//											data[i]['oc'] +
//										'</p>'+
//										'<p>'+'&nbsp;'+
//											"Amount Paid  &nbsp;&nbsp; "+ '<i class="fa fa-rupee"></i>'+
//											data[i]['tap'] +
//										'</p>'+
//									'</div>'+
//								'</div>'+		
//							'</div>';
//							
//					$('[data-role="loader"]').remove();
//				}
//				temp += '</div>';
//				//alert(temp);
//				//$(obj).closest('[data-value = "paymentHistoryCardWrap"]').after(temp);
//				$('#content-wrapper').html(temp);
//				$('[data-role="lo-pages-head"]').html('#'+ utr);
//			} 
//		})
	});
	
	
	little.views.vw_reviews = function(res){
		userHistory[userHistory.length] = 'vw_reviews';
		var temp = '';
		
		temp+='<div style="margin-top: 20px;" data-role="ajax-data-table" reponse-type="json" bottom-distance="100" data-url="" data-page-no="" data-limit="" is-loading="false" callback="vw_reviewsScrollData" data-url-type="GET" data-headers="TRUE">'+	
		
		 	  '</div>';
		
		$('#content-wrapper').html(temp);
		$('[data-role="lo-pages-head"]').html('Reviews');
		$('[data-role="ajax-data-table"]').trigger('scroll-data');
	}
	
	little.views.vw_reviewsScrollData = function(res,obj){
//		var userComments = res['r'][0]['cmts'];
        var userComments = cmt;
		var cnt = cmt.length;
		var temp = '';
        
		temp+='<div style="background-color:'+color.white_1+';">';
		temp+=addRatingView(tr, tr_avg);
		
		if(cnt == 0){
			temp += '<div class="row">'+
				    	'<div class="col s12">'+
				        	'<div class="card center">'+
				           		'<div class="card-content gray-text col s12" style="text-align:center">'+
				              		'<div class="col s12"><h6>No Record Found</nobr></h6>'+
				            	'</div>'+
				          	'</div>'+
				        '</div>'+
				      '</div>';
		}else{
		
			for(var i=0;i<cnt;i++){
				temp += '<div class="row">'+
			        		'<div class="col s12">'+
			          		  '<div class="card white darken-1">'+
			            		'<div class="card-content">'+
			            			'<div class="col s3">'+
			  							'<img src="../images/icons/user_draw.png" style="width: 50px; height: 50px" class="circle"></div>'+
			  								'<div class="col s9">'+
			              						'<b><span id="name">'+(userComments[i]['p']).substring(0,3)+'XXXXXX'+(userComments[i]['p']).substring(10,13)+'</span></b>'+
			              						//'<span class="col s12 no-padding">10/03/2015</span>'+
			              						'<p class="col s12 no-padding">'+
			              							'<span class="stars">'+parseInt(userComments[i]['r'])+'</span>'+
			              						'</p>'+
			            						'<div class="row">'+
			            							//'<span class="col s12 no-padding"><b>'+userComments[i]['cmt_for']+'</b></span>'+
			            							'<span class="col s12 no-padding">'+userComments[i]['c']+'</span>'+
			            						'</div>'+
				          					'</div>'+
			          					'</div>'+
			        		  		'</div>'+
			      				'</div>'+
			      			'</div>';
				
			}
		}
		temp+='</div>';
		$(obj).append(temp);
		$('span.stars').stars();
	}
	
	$.fn.stars = function() {
		//alert();
        console.log("stars - "+$(this).html());
        var finalVal = $(this).html();
        if(finalVal === parseInt(finalVal, 10)){
            
        }else{
            finalVal = 0;
        }
        console.log("stars ff - "+finalVal);
		return $(this).each(function(){
			$(this).html($('<span />').width(Math.max(0, (Math.min(5, parseFloat(finalVal)))) * 16));
		});
	}
	
	little.views.vw_redemption = function(res){
		userHistory[userHistory.length] = 'vw_reviews';
		var temp = '';
		
        var outletUrl = little.constants.API.DASHBOARD_OUTLETS;
        if(outletUrl === undefined || outletUrl === ''){
            globalOutlet = true;
            temp+='<div id="redeem_scroll_div" style="margin-top: 20px;" data-role="ajax-data-table" reponse-type="json" bottom-distance="100" data-url="dummy_url" data-page-no="" data-limit="" is-loading="false" callback="vw_redemptionScrollData" data-url-type="GET" data-headers="TRUE">'+	'</div>';
        }else{
            globalOutlet = false;
            temp+='<div style="margin-top: 20px;" data-role="ajax-data-table" reponse-type="json" bottom-distance="100" data-url='+little.constants.API.DASHBOARD_OUTLETS+' data-page-no="" data-limit="" is-loading="false" callback="vw_redemptionScrollData" data-url-type="GET" data-headers="TRUE">'+	'</div>';
        }
		
		$('#content-wrapper').html(temp);
		$('[data-role="lo-pages-head"]').html('Redemption');
		$('[data-role="ajax-data-table"]').trigger('scroll-data');
	}
	
    function out_click(){
        $('#m_select').show();
        open($('#m_select'));
    }

    function open(elem) {
        if (document.createEvent) {
            var e = document.createEvent("MouseEvents");
            e.initMouseEvent("mousedown", true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);
            elem[0].dispatchEvent(e);
        } else if (element.fireEvent) {
            elem[0].fireEvent("onmousedown");
        }else{
        }
    }


    function addActivityItem(){
          //option is selected
//          alert("yeah");
//        console.log('onChange');
        $('#m_select').hide();
        $('#outlet_btn').html($('#m_select').find(":selected").text());
        selectedOptionForOutlet = $('#m_select').find(":selected").val();
    }
	
	little.views.vw_redemptionScrollData = function(res,obj){
	//little.views.vw_redemption = function(res){
		//$('#mNameWrap').remove();
		$("div:visible[id*='mNameWrap']").remove();
		
		userHistory[userHistory.length] = 'vw_redemption';
		var temp = '';
		if(res['mrrq'] == 0){
			//temp += 'Oops! Your account is not activated for redemption. Please contact your account manager to activate OR write to care@checklittle.com';
			temp += '<div class="row">'+
						'<div class="col s12 center">'+
							'<img src="../images/icons/no_connection_icon.png" />'+
							'<p style="padding:10px;font-size:16px;">'+
								'Oops! Your account is not activated for Redemption.'+ 
								' Please contact your account manager to activate. <br /> OR <br /> '+
								'write to <a class="blue-text text-darken-3" href="mailto:care@checklittle.com"><b>care@checklittle.com</></a>'+
							'</p>'+
							// '<p>'+
								// '<a class="waves-effect waves-light btn-large col s12" style="background-color:#5a0f5a;color:#fff;">'+
									// 'Oops! Your account is not activated for redemption.'+ 
									// 'Please contact your account manager to activate OR write to care@checklittle.com'+
								// '</a>'+
							// '</p>'+
						'</div>'+
					'</div>';	
		}else{

            console.log(res.length);
            var c_mr_len = res.length;
            var childMerchantList = "";
            if(globalOutlet){
                childMerchantList = '<div style="text-align:center;padding-top:10px;font-size:16px;"><span style>'+globalMerchantName+'</span></div>';
                selectedOptionForOutlet = globalMerchantCode;
                isOutletDropDown = false;
            }else{
                if(res === undefined){
                    // Simple Merchant Name
                    childMerchantList = '<div style="text-align:center;padding-top:10px;font-size:16px;"><span style>'+globalMerchantName+'</span></div>';
                    selectedOptionForOutlet = globalMerchantCode;
                    isOutletDropDown = false;
                }else if(c_mr_len !== undefined && c_mr_len === 1){
                    // Single Merchant Name
                    childMerchantList = '<div style="text-align:center;padding-top:10px;font-size:16px;"><span>'+res[0].mcname+'</span></div>';

                    selectedOptionForOutlet = res[0].mc;
                    isOutletDropDown = false;
                }else if(c_mr_len !== undefined && c_mr_len > 1){
                    // Drop Down Merchant List
    //                childMerchantList += '<div id="outlet_btn" onclick="out_click()"><a >'+
    //							'Select Outlet'+'</a>';
                    childMerchantList += '<div><button id="outlet_btn" onclick="out_click()">Select Outlet</button> ';
    //                childMerchantList = '<div><button id="outlet_btn" data-role="outlet-role">Select Outlet</button>';
                    childMerchantList += '<select onchange="addActivityItem()" id="m_select" class="browser-default" style="display: none;">';

                    childMerchantList += '<option style="font-size:13px" selected="" value="" disabled="">Select Outlet</option>';

                    for(var i=0;i<c_mr_len;i++){
                         childMerchantList += 
                             '<option style="font-size:12px" value="'+res[i].mc+'">'+''+res[i].mcname+'</option>';
                    }
                    childMerchantList += '</select></div>';
                    isOutletDropDown = true;

                }else{
                    isOutletDropDown = false;
                }
            }
            

//            console.log(childMerchantList);
            
//            childMerchantList = '<select id="m_select" class="browser-default ng-pristine ng-valid ng-touched" ng-model="selectedOutlet" style="border-color:#ddd;margin:20px;">'+
//                '<option ng-repeat="outlet in outlets " value="mc-0092157" class="ng-binding ng-scope">mc-0092157 - Mast Kalandar (VIMAN NAGAR,Pune) </option></select>';
//            
//            childMerchantList = '<div style="text-align:center;padding-top:10px;"><span>Merchant</span></div>';
            
            temp += '<div style="width:1px;height:1px;" class="input-field col s12">'+
                                        '<input id="hiddenInputTop" name="ht" type="text">'+
                                    '</div>';
            
            if(isUpdateAvailable() === "true"){
                temp += addUpdateView('update_div', 'updateApp', -13);       
            }
            
			temp += '<div style="margin-top: 5px;" data-role="ajax-response-msg" class="col s12 center"></div>'+
					'<div data-role="redemption-widget" class="row card" style="border: 1px solid #ccc;padding: 0px;margin-left:10px;margin-right:10px;margin-top:0px;margin-bottom:10px;padding-bottom: 20px;">'+
//                '<a id="get_offer" data-role="merchant-outlet-role" class="waves-effect waves-light btn col s4 offset-s1" style="background-color:#5a0f5a;color:#fff;">'+
							childMerchantList+
//						'</a>'+
						'<div class="input-field col s12">'+
							'<input data-role="coupon-code" id="couponCode" name="couponCode" type="text">'+
							'<label for="couponCode" style="color:#894889">Enter Voucher Code</label>'+
						'</div>'+
						'<a id="get_offer" data-role="get-deal-redeem" class="waves-effect waves-light btn col s4 offset-s1" style="background-color:#5a0f5a;color:#fff;">'+
							'Get Offer'+
						'</a>'+
						'<a onclick="$(\'#couponCode\').val(\'\');$(\'#redemptionMsg\').remove();$(\'#dealDetailRedemptionMsg\').remove();" class="waves-effect waves-light btn col s4 offset-s2 grey" style="color:#fff;">'+
							'Reset'+
						'</a>'+
                '<div style="margin-top:140px" class="divider"></div>'+
					'<span style="text-align: center;width: 100%;display: table;position: relative;bottom: 0px;">OR</span>'+
					'<div class="row" style="margin-top:15px">'+
						'<div class="col s12 center" style="bottom: 80px;margin:0 auto;text-align:center;right:0;">'+
							'<a class="waves-effect waves-light btn-large col s12" style="background-color:#5a0f5a;color:#fff;" onclick="scanNow()">'+
								'<span class="col s12">'+
									//'<span style="display:table;float:left;padding: 4px 10px;width: 40%;text-align:right"><img style="height: 20px;" src="../images/icons/camera.png" /></span>'+
									'<span style="display:table;float:left;padding: 0px 10px;width: 40%;text-align:right"><i style="font-size:30px;" class="fa fa-camera white-text"></i></span>'+
									'<span style="display:table;float:left;width: 60%;text-align:left">Scan Code</span>'+
								'</span>'+
							'</a>'+
						'</div>'+
					'</div>'+
					'</div>';
//					'<div style="margin-top:80px" class="divider"></div>'+
//					'<span style="text-align: center;width: 100%;display: table;position: relative;bottom: 10px;">OR</span>'+
//					'<div class="row" style="margin-top:80px">'+
//						'<div class="col s12 center" style="bottom: 80px;margin:0 auto;text-align:center;right:0;">'+
//							'<a class="waves-effect waves-light btn-large col s12" style="background-color:#5a0f5a;color:#fff;" onclick="scanNow()">'+
//								'<span class="col s12">'+
//									//'<span style="display:table;float:left;padding: 4px 10px;width: 40%;text-align:right"><img style="height: 20px;" src="../images/icons/camera.png" /></span>'+
//									'<span style="display:table;float:left;padding: 0px 10px;width: 40%;text-align:right"><i style="font-size:30px;" class="fa fa-camera white-text"></i></span>'+
//									'<span style="display:table;float:left;width: 60%;text-align:left">Scan Code</span>'+
//								'</span>'+
//							'</a>'+
//						'</div>'+
//					'</div>';
					
			//temp += '<div class="row"><div class="col s12 m12 l12"><div class="white card">Saurabh</div></div></div>';
			
		}
		
		$('#content-wrapper').html(temp);
		//$('[data-role="lo-pages-head"]').html('Redemption');
		//$('[data-role="nav-item"][data-ref="menuScreen"]').attr("menu-active",'false');
		resetTabPlacing(3);
	}
    
     $(document).on('click','a[data-role="outlet-role"]',function(){
         alert('role');
     });
    
    function resetRedeemViews(){
//        $('#couponCode').val('');
        $('#redemptionMsg').remove();
        $('#dealDetailRedemptionMsg').remove();
    }
    
    var oc, oc_h;
    var redeem_now_loading = false;
    
    $(document).on('click','a[data-role="get-deal-redeem"]',function(){
        
        if(redeem_now_loading === false){
            $('#redemptionMsg').remove();
		var spinner = '<div class="preloader-wrapper active">'+
					      '<div class="spinner-layer spinner-blue">'+
					        '<div class="circle-clipper left">'+
					          '<div class="circle"></div>'+
					        '</div><div class="gap-patch">'+
					          '<div class="circle"></div>'+
					        '</div><div class="circle-clipper right">'+
					          '<div class="circle"></div>'+
					        '</div>'+
					      '</div>';	
		

//            console.log(parseInt($(window).width()));
            
		var obj = this;
		
		//alert("hi");
		//console.log($('#couponCode'));
		//alert($('#couponCode').val());
		//var coponCode = $(this).parent('div[data-role="coupon-code"]').val();
		var db = getLocalStorage();
		var merchantCode = db.getItem('merchantCode');
		
		var couponCode = ($('#couponCode').val());
		//console.log(couponCode);return;
		if(couponCode == ''){
			$(obj).html('Get Offer').removeClass('disabled');
			//Materialize.toast('Order code is empty in the Order input', 4000,'center');return;
			
            var temp = '<div id = "redemptionMsg" class="row white card" style="margin-top: 0px;margin-bottom:10px;margin-left:10px;margin-right:10px;border: 1px solid #ccc;padding: 0px;padding-top: 0px;padding-bottom:10px;padding-left:10px;padding-right:10px">'+
								'<div style="position: relative; text-align: left">'+
									'<p syle="color:'+color.red+'">'+
					              	'</p>'+
									'Voucher code cannot be empty.' +
								'</div>'+
							'</div>';
            
			$(temp).insertBefore('[data-role="redemption-widget"]');return;
			//alert("Coupon Code Required");
		}
            
        if(isOutletDropDown){
            selectedOptionForOutlet = $('#m_select').find(":selected").val();    
        }
        if(selectedOptionForOutlet === undefined || selectedOptionForOutlet === ''){
//            Materialize.toast('Please select outlet', 2000,'center');
            $('#redemptionMsg').remove();
            var temp = '<div id = "redemptionMsg" class="row white card" style="margin-top: 0px;margin-bottom:10px;margin-left:10px;margin-right:10px;border: 1px solid #ccc;padding: 0px;padding-top: 0px;padding-bottom:10px;padding-left:10px;padding-right:10px">'+
								'<div style="position: relative; text-align: left">'+
									'<p syle="color:'+color.red+'">'+
					              	'</p>'+
									'Please select outlet.' +
								'</div>'+
							'</div>';		
				$(temp).insertBefore('[data-role="redemption-widget"]');
            return;
        }
            
        $(obj).html(spinner).addClass('disabled');
            
//        else if(selectedOption === ''){
//            Materialize.toast('Please select outlet.', 2000,'center');
//            return;
//        }
		var data = {"who": { "p": "+919845035265" },"o": {"mc": merchantCode,"aoc": couponCode}};
        var d = {"oc": couponCode};
//        console.log(little.constants.API.DASHBOARD_DEAL+couponCode);
		$.ajax({
			url:little.constants.API.DASHBOARD_DEAL+couponCode,
			type: 'GET',
            headers: little.constants.LITTLE_HEADERS,
			dataType: 'json',
			contentType: 'application/json',
//			data:JSON.stringify(d),
            beforeSend: function(xhr){
		        	//$(obj).attr('is-loading',true);
                
                resetRedeemViews();
                $('#couponCode').blur();
		        	$.each(little.constants.LITTLE_HEADERS.VALUES,function(index,value){
						xhr.setRequestHeader(index,value);	
					});
		        },
			error: function (request, status, error) {
                $('#couponCode').blur();
                 redeem_now_loading = false;
				$(obj).html('Get Offer').removeClass('disabled');
				//alert();
//                console.log(request.responseText);
				var data = $.parseJSON(request.responseText);
				//Materialize.toast(data.dm, 4000,'notificationMsg')
				//Materialize.toast(data.dm, 4000,'notificationMsg')
                
                var temp = '<div id = "redemptionMsg" class="row white card" style="margin-top: 0px;margin-bottom:10px;margin-left:10px;margin-right:10px;border: 1px solid #ccc;padding: 0px;padding-top: 0px;padding-bottom:10px;padding-left:10px;padding-right:10px">'+
								'<div style="position: relative; text-align: left">'+
									'<p syle="color:'+color.red+'">'+
					              	'</p>'+
									data.dm +
								'</div>'+
							'</div>';	
                
				$(temp).insertBefore('[data-role="redemption-widget"]');
							
				//Materialize.toast('Coupon Approved.Please honour the deal to the customer', 4000,'notificationMsg');
				//$('[data-role="ajax-response-msg"]').html(data.em);
			},
			success: function(res){
                $('#couponCode').blur();
				$(obj).html('Get Offer').removeClass('disabled');
				redeem_now_loading = false;
//				console.log(res);
				//var data = $.parseJSON(res);
				//console.log(data);
				//alert(res.dm);
				//alert(res['d']['mn']);
				var temp_old = '<div id = "dealDetailRedemptionMsg" class="row white card" style="margin-top: 0px;border: 1px solid #ccc;padding: 0px;padding-bottom: 20px;">'+
								'<div class="input-field col s12">'+
									'<div style="color: '+color.green_dark_1+';">'+
//					              		'<span style="display:table-cell;vertical-align: middle;width:10%;"><img style="height: 20px;" src="../images/icons/tick.png" /></span>'+
					              		'<span style="display:table-cell;width:90%;padding-left:10px">Verified</span>'+
					              	'</div>'+
					              	
									'<div style="color: '+color.green_dark_1+';">'+""+'</div>'+
									'<div><b>Deal Details</b></div>'+
					                '<span class="card-title  blue-grey-text text-darken-1"><i style="padding-right:10px" class="fa fa-map-marker grey-text text-darken-2"></i>'+res.mn+'</span>'+
					              	'<div>'+
					              		'<i class="fa fa-bullhorn grey-text text-darken-2"></i>'+
					              		'<span style="padding-left:10px">'+res.dn+'</span>'+
					              	'</div>'+
									'<div>Coupon Code: '+res.oc+'</div>'+
									'<div>Quantity: '+res.qty+'</div>'+
								'</div>'+
							'</div>';		
							
                oc = res.oc;
                oc_h = res.oc_h;
				var temp = '<div id = "dealDetailRedemptionMsg" class="row white" style="margin-left:10px;margin-right:10px;margin-bottom:50px;border: 1px solid #ccc;padding: 0px;padding-bottom: 20px;font-size:16px;">'+
								'<div class="col s12 m12" style="color:#2d2d2d">'+
									'<div class="col s12 center green-text text-darken-1" style="font-size: 30px;padding: 10px;">'+
//				              			'<span style="font-size:50px;margin-top:10px;">'+
//				              				'<i class="fa fa-check-circle"></i>&nbsp;&nbsp;'+
//				              			'</span>'+
//				              			'<span>'+
//				              				'<span>VERIFIED</span>'+
//				              			'</span>'+
					              	'</div>'+
					              	
									'<div class="col s12 m12 left" style="color: #777;font-size:16px;">'+res.mn+'</div>'+
                                    '<div class="col s12 m12 left" style="color: #5a0f5a;font-size:24px;">'+res.oc+'</div>';
                
                if(res.sd === true){
                    temp += '<div class="col s12 m12 left" style="color: #777;font-size:16px;">'+'UNIT PRICE'+'</div>'+
                    '<div class="col s12 m12"><span style="font-size:19px;color:#5a5a5a;padding-right:10px;"><strike><i class="fa fa-rupee"></i> '+res.mrp+'</strike></span>'+
					              		'<span style="font-size:23px;color:#5a0f5a"><i class="fa fa-rupee"></i> '+res.sp+'</span>'+
					              	'</div>'+
                    '<div class="col s12 m12">QTY: '+res.qty+'</div>';
                }
					              	
                
                
									temp += '<div class="divider grey-text col s12 m12" style="margin: 5px 0;">&nbsp;</div>'+
//					                '<span class="col s12 m12" style="font-size:19px;color:#1a2e61">'+
//					                	res.mn+
//					                '</span>'+
					              	'<span class="col s12 m12" style="font-size:24px;margin-top:10px;margin-bottom:10px;"><b>'+
					              		res.dn+
					              	'</b></span>';
//					              	'<div class="col s12 m12">'+
//					              		'<span style="font-size:19px;color:#5a5a5a;padding-right:10px;"><strike><i class="fa fa-rupee"></i> '+res.mrp+'</strike></span>'+
//					              		'<span style="font-size:23px;color:#b3324e"><i class="fa fa-rupee"></i> '+res.sp+'</span>'+
//					              	'</div>'+
//									'<div class="col s12 m12" style="margin:10px 0 0 0;">Coupon Code: '+res.oc+'</div>'+
//									'<div class="col s12 m12">Quantity: '+res.qty+'</div>'+
//									'<div class="col s12 m12" style="margin:0px 0 10px 0;">Expires On: '+(res.oed*1000).sectodate('d M Y')+'</div>';
                                    
                
                temp += '<div style="width:0px;height:0px;" class="input-field col s12">'+
							'<input id="hiddenInput" name="h" type="text">'+
						'</div>';
                
                
									if(res.tc != ''){
                                        var tc_arr = res.tc.split("\n");
//                                        console.log(tc_arr);
                                        temp += '<div class="col s12 m12"><b>Terms & Conditions</b>';
                                        for(var i=0;i<tc_arr.length;i++){
                                            temp += '<div class="col s12 m12">&#9679;  '+tc_arr[i]+'</br>'+'</div>';
                                        }
                                       
										
										//for(var i=0;i<(res['d']['dtc']).length;i++){
//                                        console.log(res.tc);
//											temp += '<div class="col s12 m12">'+(res.tc).join('</br>')+'</div>';
//                                        temp += '<div class="col s12 m12">'+res.tc+'</br>'+'</div>';
										//}
									}
								temp += '</div>'+
                                    '<div id="redeem_now_btn" style="text-align: center;"><a data-role="coupon-redemption" class="waves-effect waves-light btn col s4 offset-s1" style="background-color:#5a0f5a;color:#fff;width:80%;margin-top:20px;">'+
							'<span align="center" style="height:55px;">Redeem Now</span>'+
						'</a></div>'+
							'</div>';
				$(temp).insertAfter('[data-role="redemption-widget"]');
				
                document.getElementById("hiddenInput").focus();
                $('#hiddenInput').blur();
                
//				Materialize.toast(res.s, 4000,'notificationMsg');

				//alert(res);
			},complete: function(xhr, textStatus) {
                      
            } 
		})
        }
		
	});

	$(document).on('click','a[data-role="coupon-redemption"]',function(){
//		$('#redemptionMsg').remove();
//        console.log('Redeem Now Click');
        
//        console.log("select - "+selectedOptionForOutlet);
        
        $('#redeem_now_btn').remove();
		var spinner = '<div class="preloader-wrapper active">'+
					      '<div class="spinner-layer spinner-blue">'+
					        '<div class="circle-clipper left">'+
					          '<div class="circle"></div>'+
					        '</div><div class="gap-patch">'+
					          '<div class="circle"></div>'+
					        '</div><div class="circle-clipper right">'+
					          '<div class="circle"></div>'+
					        '</div>'+
					      '</div>';	
		
		var obj = this;
		$(obj).html(spinner).addClass('disabled');
		//alert("hi");
		//console.log($('#couponCode'));
		//alert($('#couponCode').val());
		//var coponCode = $(this).parent('div[data-role="coupon-code"]').val();
		var db = getLocalStorage();
		var merchantCode = db.getItem('merchantCode');
		
		var couponCode = ($('#couponCode').val());
		//console.log(couponCode);return;
//		if(couponCode == ''){
//			$(obj).html('Verify').removeClass('disabled');
//			//Materialize.toast('Order code is empty in the Order input', 4000,'center');return;
//			
//			var temp = '<div id = "redemptionMsg" class="row white card" style="margin-top: 50px;border: 1px solid #ccc;padding: 0px;margin: 30px 8px;padding-bottom: 20px;">'+
//							'<div class="input-field col s12">'+
//								'<p syle="color:#b71c1c">'+
////				              		'<span style="display:table-cell;vertical-align: middle;width:10%;"><img style="height: 20px;" src="../images/icons/cross_red.png" /></span>'+
////				              		'<span style="display:table-cell;width:90%;padding-left:10px;color:#b71c1c">Something went wrong</span>'+
//				              	'</p>'+
//								'Voucher code cannot be empty.' +
//							'</div>'+
//						'</div>';		
//			$(temp).insertAfter('[data-role="redemption-widget"]');return;
//			//alert("Coupon Code Required");
//		}
//		var data = {"who": { "p": "+919845035265" },"o": {"mc": merchantCode,"aoc": couponCode}};
        var d = {"oc": oc, "h": oc_h, "rmc": selectedOptionForOutlet};
        console.log(d);
//        console.log(little.constants.LITTLE_HEADERS);
//        console.log("url - "+little.constants.API.DASHBOARD_REDEEM);
		$.ajax({
			url:little.constants.API.DASHBOARD_REDEEM,
			type: 'POST',
            headers: little.constants.LITTLE_HEADERS,
			dataType: 'json',
			contentType: 'application/json',
			data:JSON.stringify(d),
            beforeSend: function(xhr){
//                console.log("before");
		        	//$(obj).attr('is-loading',true);
                redeem_now_loading = true;
//                window.scrollTo(0, -1000);
//                window.location = '#';
//                $('body').animate({scrollTop:0}, 'slow');
                
                document.getElementById("couponCode").focus();
                $('#couponCode').blur();
                
                var sp = '<div id="rd_spinner" class="col s12 center" data-role="scroll-data-loader">'+
				        				 '<div class="preloader-wrapper big active">'+
										    '<div class="spinner-layer spinner-blue-only">'+
										      '<div class="circle-clipper left">'+
										        '<div class="circle"></div>'+
										      '</div><div class="gap-patch">'+
										        '<div class="circle"></div>'+
										      '</div><div class="circle-clipper right">'+
										        '<div class="circle"></div>'+
										      '</div>'+
										    '</div>'+
										  '</div>'+
									   '</div>'; 
                $('#rd_spinner').show();
                $(sp).insertBefore('[data-role="redemption-widget"]');
                
		        	$.each(little.constants.LITTLE_HEADERS.VALUES,function(index,value){
						xhr.setRequestHeader(index,value);	
					});
		        },
			error: function (request, status, error) {
//                console.log("error - "+error);
                redeem_now_loading = false;
                $('#rd_spinner').remove();
//				$(obj).html('Verify').removeClass('disabled');
				//alert();
				var data = $.parseJSON(request.responseText);
//				console.log(data.em);
				//Materialize.toast(data.dm, 4000,'notificationMsg')
				//Materialize.toast(data.dm, 4000,'notificationMsg')
				
				var temp = '<div id = "redemptionMsg" class="row white card" style="margin-top: 50px;border: 1px solid #ccc;padding: 0px;margin: 30px 8px;padding-bottom: 20px;">'+
//                    '<div style="width:1px;height:1px;" class="input-field col s12">'+
//                                        '<input id="hiddenInputTop" name="ht" type="text">'+
//                                    '</div>'+
								'<div class="input-field col s12">'+
									'<p syle="color:#b71c1c">'+
//					              		'<span style="display:table-cell;vertical-align: middle;width:10%;"><img style="height: 20px;" src="../images/icons/cross_red.png" /></span>'+
//					              		'<span style="display:table-cell;width:90%;padding-left:10px;color:#b71c1c">Something went wrong</span>'+
					              	'</p>'+
									data.dm +
								'</div>'+
							'</div>';		
				$(temp).insertBefore('[data-role="redemption-widget"]');
							
				//Materialize.toast('Coupon Approved.Please honour the deal to the customer', 4000,'notificationMsg');
				//$('[data-role="ajax-response-msg"]').html(data.em);
			},
			success: function(res){
                $('#rd_spinner').remove();
                redeem_now_loading = false;
//                console.log("success");
//				$(obj).html('Verify').removeClass('disabled');
				
				console.log(res);
				//var data = $.parseJSON(res);
				//console.log(data);
				//alert(res.dm);
				//alert(res['d']['mn']);
							
				var temp = '<div id = "redemptionMsg" class="row white" style="margin-top: 10px;margin-left:10px;margin-right:10px;margin-bottom:10px;border: 1px solid #ccc;padding: 0px;padding-bottom: 20px;font-size:16px;">'+
								'<div class="col s12 m12" style="color:#2d2d2d">'+
									'<div class="col s12 center green-text text-darken-1" style="font-size: 30px;padding: 10px;">'+
//				              			'<span style="font-size:50px;margin-top:10px;">'+
//				              				'<i class="fa fa-check-circle"></i>&nbsp;&nbsp;'+
//				              			'</span>'+
//				              			'<span>'+
//				              				'<span>VERIFIED</span>'+
//				              			'</span>'+
					              	'</div>'+
//					              	'<div style="width:1px;height:1px;" class="input-field col s12">'+
//                                        '<input id="hiddenInputTop" name="ht" type="text">'+
//                                    '</div>'+
									'<div class="col s12 m12 center" style="color: #56ae4e;font-size:24px;">'+res.dm+'</div>';
//									'<div class="divider grey-text col s12 m12" style="margin: 5px 0;">&nbsp;</div>'+
//					                '<span class="col s12 m12" style="font-size:19px;color:#1a2e61">'+
//					                	res.mn+
//					                '</span>'+
//					              	'<span class="col s12 m12" style="font-size:17px;">'+
//					              		res.dn+
//					              	'</span>'+
//					              	'<div class="col s12 m12">'+
//					              		'<span style="font-size:19px;color:#5a5a5a;padding-right:10px;"><strike><i class="fa fa-rupee"></i> '+res.mrp+'</strike></span>'+
//					              		'<span style="font-size:23px;color:#b3324e"><i class="fa fa-rupee"></i> '+res.sp+'</span>'+
//					              	'</div>'+
//									'<div class="col s12 m12" style="margin:10px 0 0 0;">Coupon Code: '+res.oc+'</div>'+
//									'<div class="col s12 m12">Quantity: '+res.qty+'</div>'+
//									'<div class="col s12 m12" style="margin:0px 0 10px 0;">Expires On: '+(res.oed*1000).sectodate('d M Y')+'</div>';
//									if(res.tc != ''){
//										temp += '<div class="col s12 m12">Terms & Conditions</div>';
//										//for(var i=0;i<(res['d']['dtc']).length;i++){
//                                        console.log(res.tc);
////											temp += '<div class="col s12 m12">'+(res.tc).join('</br>')+'</div>';
//                                        temp += '<div class="col s12 m12">'+res.tc+'</br>'+'</div>';
//										//}
//									}
								temp += '</div>'+
							'</div>';
				$(temp).insertBefore('[data-role="redemption-widget"]');
//                window.location = '#';
//                window.scrollTo(0, 0);
//                $(window).width();
//                console.log(parseInt($(window).width()));
                
//                $('body').animate({scrollTop:0}, 'slow');
//                $(window).scrollTop(0);
                
//                document.body.scrollTop = document.documentElement.scrollTop = 0;
				
//                $("html, body").animate({ scrollTop: $(document).height()-$(window).height() });
                
//				Materialize.toast(res.s, 4000,'notificationMsg');
				
				//alert(res);
			},
            complete: function(xhr, textStatus) {
                document.getElementById("hiddenInputTop").focus();
                $('#hiddenInputTop').blur();
            } 
		})
	});

	//$(document).on('scroll-data', '[data-role="ajax-data-table"]',function(){
	

	little.controllers.template = function(params){
		this.config = {
			contentFunc:function(){
				return 'Content function not defined';
			}
		}
		
		this.init = function(){
			var lo = this;
			lo.page();
			
			$(document).on('click','a[data-role="nav-item"]',function(){
				$('#menu-wrapper').html('');
				$('[data-role="lo-pages-menu"]').hide();
				$('[data-role="lo-pages-head"]').show();
				
				//$('[data-role="nav-item"][data-ref="menuScreen"]').attr("menu-active",'false');
				var data = '';
				var url = $(this).attr('data-url');
//                console.log("url - "+url);
				var responseType = ($(this).attr('response-type')==undefined || $(this).attr('response-type')=='')?'json':$(this).attr('response-type');
				var type = (($(this).attr('data-url-type'))==undefined || ($(this).attr('data-url-type'))=='')?'GET':$(this).attr('data-url-type');
				//alert(url);
				
				var callback = $(this).attr('data-callback');
				if(url=='' || url==undefined){
					little.views[callback](data,this);
					return;
				}
				
				$.ajax({
			        url: url,
			        type: type,
			        async: true,
			        beforeSend: function(xhr) {
						$.each(little.constants.LITTLE_HEADERS.VALUES,function(index,value){
							xhr.setRequestHeader(index,value);	
						});
					},
		            success: function(response){
		            	if(responseType=='json'){
//                            console.log(response);
//			            	var data=$.parseJSON(response);
                            var data=response;
			            }else{
			            	var data=response;
			            }
			            //$$.views[THIS.config.responseHandler](data,THIS.config.responseWrapper);
			            little.views[callback](data);
                
		            }, 
		            error: function (request, status, error) {
					    //alert(request.responseText);
					    little.views.vw_networkErrorMsg();
					    //var data=$.parseJSON(request.responseText);
					    //console.log(data);
					    //little.views[callback](data);
					}
			     });
				
				
				//alert(callback);
				
			});
		}
		
		this.header = function(){
			var lo = this;
			var temp = '<div class="grid grid-pad urow" data-uib="layout/row" data-ver="0">'+
	                        '<div class="col uib_col_5 col-0_4-12_4-4" data-uib="layout/col" data-ver="0">'+
	                            '<div class="widget-container content-area">'+
	                                '<button class="btn uib_w_5 d-margins btn-default" data-uib="twitter%20bootstrap/button" data-ver="1" id="leftMenu"><i class="glyphicon glyphicon-list button-icon-left" data-position="left"></i>'+ 
	                                '</button><span class="uib_shim"></span>'+
	                            '</div>'+
	                        '</div>'+
	                        '<div class="col uib_col_7 col-0_4-12_4-8" data-uib="layout/col" data-ver="0">'+
	                            '<div class="widget-container content-area vertical-col">'+
	                                '<div class="widget uib_w_13 d-margins" data-uib="media/text" data-ver="0">'+
	                                    '<div class="widget-container left-receptacle"></div>'+
	                                    '<div class="widget-container right-receptacle"></div>'+
	                                    '<div>'+
	                                        '<p>Home</p>'+
	                                    '</div>'+
	                                '</div><span class="uib_shim"></span>'+
	                            '</div>'+
	                        '</div>'+
	                        '<div class="col uib_col_6 col-0_4-12_4-8" data-uib="layout/col" data-ver="0">'+
	                            '<div class="widget-container content-area vertical-col">'+
	                                '<span class="uib_shim"></span>'+
	                            '</div>'+
	                        '</div>'+
	                        '<span class="uib_shim"></span>'+
	                    '</div>';
	    	return temp;
		}
		
		this.menu = function(){
			
			var lo = this;
		     var temp = '<nav data="top-nav-bar" style="line-height: 22px;background-color:#fff;">'+
			     			/*'<ul id="slide-out" class="side-nav">'+
			     				'<li class="no-padding" style="background:url(\'../images/welcome-bg.png\')">'+
			     					
			     					'<div class="row">'+
								      '<div class="col s12 m5 no-padding">'+
								        '<div class="card-panel teal center" style="background-color:transparent !important">'+
								          '<span class="white-text" id="localData"></span>'+
								        '</div>'+
								      '</div>'+
								    '</div>'+
			     					
			     				'</li>'+
							 	'<li class="no-padding">'+
							 		'<a id="lDashboard" style="display: table;width:100%;line-height: 55px;" data-role="nav-item" data-ref="dashboard" data-url="" data-callback="vw_dashboard" response-type="json" href="#!">'+
							 			'<span style="display:table-cell;vertical-align: middle;width:10%;"><img style="height: 28px;" src="../images/icons/ic_home.png" /></span>'+
							 			'<span style="display:table-cell;vertical-align:middle;padding-bottom: 15px;">&nbsp;&nbsp;Home</span>'+
							 		'</a>'+
							 	'</li>'+
							    '<li class="no-padding">'+
							    	'<a style="display: table;width:100%;line-height: 55px;" data-role="nav-item" data-ref="vw_deals" data-url="" data-callback="vw_deals" response-type="json" response-type="" data-url-type="" data-headers="" href="#!">'+
							    		'<span style="display:table-cell;vertical-align: middle;width:10%;"><img style="height: 28px;" src="../images/icons/ic_bullhorn.png" /></span>'+
							    		'<span style="display:table-cell;vertical-align:middle;padding-bottom: 18px;">&nbsp;&nbsp;Offers</span>'+
							    	'</a>'+
							    '</li>'+
							    '<li class="no-padding">'+
							    	'<a style="display: table;width:100%;line-height: 55px;" data-role="nav-item" data-ref="paymentHistory" data-url="" data-callback="vw_paymentHistory" response-type="json" href="#!">'+
							    		'<span style="display:table-cell;vertical-align: middle;width:10%;"><img style="height: 28px;" src="../images/icons/ic_receipt.png" /></span>'+
							    		'<span style="display:table-cell;vertical-align:middle;padding-bottom: 18px;">&nbsp;&nbsp;Payment history</span>'+
							    	'</a>'+
							    '</li>'+
							    '<li class="no-padding">'+
							    	'<a style="display: table;width:100%;line-height: 55px;" data-role="nav-item" data-ref="reviews" data-url="" data-callback="vw_reviews" response-type="json" href="#!">'+
							    		'<span style="display:table-cell;vertical-align: middle;width:10%;"><img style="height: 28px;" src="../images/icons/ic_heart.png" /></span>'+
							    		'<span style="display:table-cell;vertical-align:middle;padding-bottom: 18px;">&nbsp;&nbsp;Ratings &amp; Reviews</span>'+
							    	'</a>'+
							    '</li>'+
							    '<li class="no-padding">'+
							    	'<a style="display: table;width:100%;line-height: 55px;" data-role="nav-item" data-ref="redemption" data-url="" data-callback="vw_redemption" response-type="json" href="#!">'+
							    		'<span style="display:table-cell;vertical-align: middle;width:10%;"><img style="height: 28px;" src="../images/icons/ic_wallet_giftcard.png" /></span>'+
							    		'<span style="display:table-cell;vertical-align:middle;padding-bottom: 18px;">&nbsp;&nbsp;Coupon Redemption</span>'+
							    	'</a>'+
							    '</li>'+
							    '<li class="no-padding">'+
							    	'<a style="display: table;width:100%;line-height: 55px;" data-role="nav-item" data-ref="contact" data-url="" data-callback="vw_contact" response-type="json" href="#!">'+
							    		'<span style="display:table-cell;vertical-align: middle;width:10%;"><img style="height: 28px;" src="../images/icons/ic_contact.png" /></span>'+
							    		'<span style="display:table-cell;vertical-align:middle;padding-bottom: 18px;">&nbsp;&nbsp;Contact</span>'+
							    	'</a>'+
							    '</li>'+
							    '<li class="no-padding">'+
							    	'<a style="display: table;width:100%;line-height: 55px;" data-role="nav-item" data-ref="contact" data-url="" data-callback="vw_version" response-type="json" href="#!">'+
							    		'<span style="display:table-cell;vertical-align: middle;width:10%;"><img style="height: 28px;" src="../images/icons/ic_info.png" /></span>'+
							    		'<span style="display:table-cell;vertical-align:middle;padding-bottom: 18px;">&nbsp;&nbsp;About</span>'+
							    	'</a>'+
							    '</li>'+
							    '<li class="no-padding">'+
							    	'<a style="display: table;width:100%;line-height: 55px;" onclick="logout();">'+
							    		'<span style="display:table-cell;vertical-align: middle;width:10%;"><img style="height: 28px;" src="../images/icons/ic_power.png" /></span>'+
							    		'<span style="display:table-cell;vertical-align:middle;padding-bottom: 18px;">&nbsp;&nbsp;Logout</span>'+
							    	'</a>'+
							    '</li>'+
							 '</ul>'+*/
							 '<div style="position:fixed;background-color:#fff;width:100%;z-index:2;border-bottom:2px solid #696969">'+
							 	'<a style="width:15%;cursor:pointer;float:left" onclick="$(\'ul.tabs\').tabs(\'select_tab\', \'test1\');">'+
							 		'<img style="height: 40px;margin: 10px 0 0px 10px;" src="../images/icons/lil-merchant60x60.png" />'+
							 	'</a>'+
							 	'<span style="width:65%;display:table;padding: 27px 0 0 5px;color:#696969;font-size: 20px;float:left" class="left-align" data-role="lo-pages-head">Dashboard</span>'+
							 	'<span style="width:65%;display:table;padding: 27px 0 0 5px;color:#696969;font-size: 20px;float:left;display:none;" class="left-align" data-role="lo-pages-menu">Menu</span>'+
							 	
							 	
							 	'<a menu-active="false" style="padding: 20px 20px 0 20px;box-sizing:border-box;cursor:pointer;float:left;display:table;" data-role="nav-item" data-ref="menuScreen" data-url="" data-callback="vw_menuScreen" response-type="json">'+
							 		'<i style="font-size:30px;" class="fa fa-ellipsis-v right grey-text text-darken-2"></i>'+
							 	'</a>'+
							 '</div>'+
						'</nav>';
			
			return temp; 
		};
		
		this.page = function(){
		
		        //portrait
		        var dw = window.innerWidth
		        || document.documentElement.clientWidth
		        || document.body.clientWidth;
		
		        /*var dh = window.innerHeight
		        || document.documentElement.clientHeight
		        || document.body.clientHeight;*/
		        
		        var dh = $(window).height();
			
			//alert($('#mNameWrap').height());
			dh = dh - (($('[data-role="top-nav-bar"]').height()) + ($('[data-role="bottom-nav-bar"]').height()) + 30);
			
			var lo = this;
			var temp = '';
			temp +=	'<div class="upage">'+
						'<div class="upage-outer">'+
			                '<div class="upage-content ac0 content-area vertical-col" id="page_90_9">'+
			            		//lo.header()+
			            		lo.menu()+
			                    '<div class="grid grid-pad urow uib_row_5 row-height-5" data-uib="layout/row" data-ver="0">'+
			                        '<div class="col uib_col_9 col-0_12-12" data-uib="layout/col" data-ver="0">'+
			                            '<div class="widget-container content-area vertical-col">'+
			
			                                '<div class="widget uib_w_14 d-margins" data-uib="media/text" data-ver="0">'+
			                                    '<div class="widget-container left-receptacle"></div>'+
			                                    '<div class="widget-container right-receptacle"></div>'+
			                                    '<div id="menu-wrapper"></div>'+
			                                    '<div id="content-wrapper" style="overflow-y:scroll;-webkit-overflow-scrolling: touch;height:'+dh+'px;background-color:#EFF3F8;">'+
			                                    // '<div id="content-wrapper" style="overflow-y:scroll;-webkit-overflow-scrolling: touch;height:'+dh+'px;background-color:#EFF3F8;">'+
			                                    //'<div id="content-wrapper">'+
			                                        //'<p>Content Body</p>'+
			                                    '</div>'+
			                                '</div><span class="uib_shim"><div id="top_loader" class="col s12 center" data-role="scroll-data-loader" style="z-index:2000">'+
				        				 '<div class="preloader-wrapper big active" style="z-index:2000">'+
										    '<div class="spinner-layer spinner-blue-only" style="z-index:2000">'+
										      '<div class="circle-clipper left">'+
										        '<div class="circle" style="z-index:2000"></div>'+
										      '</div><div class="gap-patch">'+
										        '<div class="circle"></div>'+
										      '</div><div class="circle-clipper right">'+
										        '<div class="circle"></div>'+
										      '</div>'+
										    '</div>'+
										  '</div>'+
									   '</div></span>'+
			                            '</div>'+
			                        '</div>'+
			                        '<span class="uib_shim"></span>'+
			                    '</div>'+
			                '</div>'+
			                
		            	'</div>'+
		          	'</div>';
	            //alert(temp);
	    	$('#mainWrapper').html(temp);
	    	$('#top_loader').hide();
	    	$('.button-collapse').sideNav({
				menuWidth : 240, // Default is 240,
				edge : 'left', // Choose the horizontal origin
				closeOnClick : true // Closes side-nav on <a> clicks, useful for Angular/Meteor
			}); 
			
			getlocalValues();
			//$('[data-role="nav-item"][data-ref="dashboard"]').trigger('click');
			//little.views.vw_dashboard();
			setTimeout(function(){
				//alert();
				//console.log($('[data-role="nav-item"][data-ref="dashboard"]').length);
				//$('[data-role="nav-item"][data-ref="dashboard"]').click();
				//$('#lDashboard').click();
                
                
				//little.views.vw_dashboard();
                little.views.vw_redemption();
			},1000);
			
			
    	};
    	
    	this.init();
	};
	

	
	function scanNow() {
		cordova.plugins.barcodeScanner.scan(function(result) {
			//alert("We got a barcode\n" + "Result: " + result.text + "\n" + "Format: " + result.format + "\n" + "Cancelled: " + result.cancelled);
			$('#couponCode').focus();
			$('#couponCode').val(result.text);
            $('#get_offer').click();
            $('#couponCode').blur();
		}, function(error) {
			alert("Scanning failed: " + error);
		});
	}


	
	function scanNow_old() {
		alert(1);
		//this function launches the QR Code scanner. This function must be called inside a event handler.
		//intel.xdk.device.scanBarcode();
		try{
        	intel.xdk.device.scanBarcode();
    	}
        catch (err){
        	alert(err.message); //This throw "Cannot read property 'scanBarcode' of undefined"
    	}
	}
	
	//this event is fired when scanning is completed
	document.addEventListener("intel.xdk.device.barcode.scan", function(evt) {
		alert(2);
		if (evt.success == true) {
			alert(3);
			//successful scan
			var string = evt.codedata;
			alert(string);
		} else {
			alert(4);
			//failed scan
			alert("Please try again");
		}
	}, false); 
	
	
	function getlocalValues(){            
    	var db = getLocalStorage();
    	var res = document.getElementById("r");
	    var pairs;            
	    var i=0;
	    
	    var temp = '';
	    for (i=0; i<=db.length-1; i++) {
		    key = db.key(i);             
		    temp += "<div>"+ "key: "+ key +" value: "+db.getItem(key)+"</div>";;
		}  
		
		//var db = getLocalStorage();
		//$('#content-wrapper').prepend('Welcome <br />' + db.getItem('merchantName'));
	}


	function getLocalStorage(){
	    try{
	    	if(window.localStorage ) return window.localStorage;            
	    }
	    catch(e){
	    	return undefined;
	    }
	}
	
	function logout(){
		// var db = getLocalStorage();
		// db.setItem('userName' , '');
    	// db.setItem('password' , '');
    	localStorage.clear()
    	window.location.assign("../index.html");
	}
	
	little.views.vw_networkErrorMsg = function(res){
		var temp = '';
//        console.log(res);
        var msg = res.dm;
        if(msg === undefined || msg === ''){
            msg = 'Sorry for the Inconvenience. Our team is working on it. Please try again after sometimes.';
        }
		temp += '<div class="row">'+
					'<div class="col s12 center">'+
						'<img src="../images/icons/no_connection_icon.png" />'+
						'<p class="row col s12">'+
            msg+
//							'Sorry for the Inconvenience. Our team is working on it. Please try again after sometimes.'+
						'</p>'+
					'</div>'+
				'</div>';
        nwErrorCheck = true;
//        $('#top_loader').hide();
		$('#content-wrapper').show();
		$('#content-wrapper').html(temp);
//		$('[data-role="lo-pages-head"]').html('Network Error');
	}

	little.views.vw_noInternetConnection = function(res){
		var temp = '';
				
		temp += '<div class="row">'+
					'<div class="col s12 center">'+
						'<img src="../images/icons/no_connection_icon.png" />'+
						'<p style="padding:10px">Please connect to working Internet connection</p>'+
						'<p>'+
							'<a onclick="little.views.vw_dashboard();" class="waves-effect waves-light btn-large col s12" style="background-color:#5a0f5a;color:#fff;">'+
								'Try Again'+
							'</a>'+
						'</p>'+
					'</div>'+
				'</div>';
		
//        console.log('no internet');
        $('#content-wrapper').show();
		$('#content-wrapper').html(temp);
		$('[data-role="lo-pages-head"]').html('No Internet Connection');
	}
	
	$(document).ajaxStart(function() {
		$('[data-role="nav-item"][data-ref="menuScreen"]').attr("menu-active",'false');
		checkConnection();
	});
	
	function checkConnection() {
	    var networkState = navigator.connection.type;
	    if(networkState == 'none'){
			little.views.vw_noInternetConnection();
	    }
	}

	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	function initChartJs(tis,cmis){
	
			
		var area = "chart-area";
		//var area2 = "chart-area2";
		var display = tis;
		var display2 = cmis;
		var data;
		var cArea;
		var disText;
		var doughnutData = [{
			value : 360,
			color : "#4594CD",
			highlight : "#4594CD"
			//label : "red",
	
		}];
		var doughnutData2 = [{
			value : 360,
			color : "#F6A728",
			highlight : "#F6A728"						
			//label: "Green"
		}];
	
		var func1 = function(cArea, data, disText) {
			var ctx = document.getElementById(cArea).getContext("2d");
			window.myDoughnut = new Chart(ctx).Doughnut(data, {
				responsive : false,
				animateScale : true,
				animateRotate : true,
				animationEasing : "easeOutSine",
				showTooltips: false,
				animationSteps : 0,
				percentageInnerCutout : 80,
				onAnimationComplete : function() {
	
					var canvasWidthvar = $("#chart-area").width();
					var canvasHeight = $("#chart-area").height();
					var constant = 114;
					var fontsize = (canvasHeight / constant).toFixed(2);
					//ctx.font="2.8em Verdana";
					ctx.font = fontsize + "em Verdana";
					ctx.textBaseline = "middle";
					var total = 0;
					$.each(doughnutData, function() {
						total += parseInt(this.value, 10);
					});
					var tpercentage = disText;
					var textWidth = ctx.measureText(tpercentage).width;
					var txtPosx = Math.round((canvasWidthvar - textWidth) / 2);
					//alert(tpercentage+'--'+textWidth+'--'+txtPosx);
					ctx.fillText(tpercentage, txtPosx, canvasHeight / 2);
				}
			});
		};
		
		func1(area, doughnutData, display);
		//func1(area2, doughnutData2, display2);
	}
	
	
	document.addEventListener("backbutton", backButtonPressed, false);
	
	function backButtonPressed() {
        console.log("length - "+userHistory);
        console.log('backPressed - '+userHistory[(userHistory.length)-1]);
        $('#m_select').hide();
		//intel.xdk.device.addVirtualPage();
		//alert("hi");
		
		//alert([userHistory[userHistory.length-1]]);
		//alert((userHistory.length)-1);
		//alert(userHistory[3]);
		//alert(userHistory[(userHistory.length)-1]);
        
		userHistory.splice(userHistory.length-1,1);
		
		if(userHistory[(userHistory.length)-1] == undefined){
			//little.views.vw_dashboard();
			navigator.app.exitApp();
		}
		
		little.views[userHistory[(userHistory.length)-1]]();
		userHistory.splice(userHistory.length-1,1);
		//var len = userHistory.length;
		//alert(len);
		//console.log(userHistory);
		//console.log(temp);
	    // Optionally, processes before quitting the app: save variables, log changes, etc.
	    //alert("hi");
	
	    // exit the application
	    //navigator.app.exitApp();
	
	}
	
	// document.addEventListener("intel.xdk.device.hardware.back", function() {
//     
	    // //continue to grab the back button
	    // intel.xdk.device.addVirtualPage(); 
// 	    
	    // document.getElementsByTagName("body")[0].innerHTML += "Hardware back button pressed";
// 	    
	// }, false);   
	
	
	resetTabPlacing = function(tabNo){
		var screenWidth = $(window).width();
		var tabWidth = $('.tabs li').outerWidth();
		
		
		var right = (screenWidth - (tabNo*tabWidth));
		var left  = (screenWidth - (right + tabWidth));

		$('.indicator').css({'left':left+'px','right':right+'px'});		
	}
	
	
	$('html').click(function() {
	//Hide the menus if visible
		if($('#couponCode').is(":focus")){
			$('#bFixedNavBar').hide();
		}else{
			$('#bFixedNavBar').show();
		}
	});

	document.addEventListener("intel.xdk.device.ready",onDeviceReadyHideStatus,false);
	function onDeviceReadyHideStatus(evt){
		intel.xdk.device.hideStatusBar();
	} 

	// document.addEventListener('deviceready', onDeviceReady, false);
	// function onDeviceReady () {
		// alert("hi");
		// document.addEventListener('hidekeyboard', onKeyboardHide, false);
	    // document.addEventListener('showkeyboard', onKeyboardShow, false);
	// }
// 	
	// function onKeyboardHide() {
		// alert(1);
	    // //$('#sp_menu_app').show();
	   	// //$('#toSubject').blur();
	   	// //$('#currentMessage').blur(); 
	// }
// 	
	// function onKeyboardShow() {
		// alert(2);
	   	// //$('#sp_menu_app').hide();
	// }


	
    // window.addEventListener("load", function() {
        // window.scrollBy(0, 100);
    // }, false);

	
	/*$(document).ready(function(){
		$("#content-wrapper").scroll(function () {
			if ($(this).scrollTop() < 0) {
				$('.pullToRefresh').remove();
				var temp =  '<div class="row pullToRefresh">'+
							   		'<span style="padding:20px 0 0 0;" class="center col s12">'+
							   			'<i class="fa fa-spin fa-spinner"></i>&nbsp;&nbsp;'+
							   			'Loading...'+
							   		'</span>'+
							    '</div>';
			        
			    $('#content-wrapper').prepend(temp);
		   	}
		    if ($(this).scrollTop() == 0) {
		        little.views[userHistory[(userHistory.length)-1]]();
		    }
		});
	});*/
	
	// $(document).ready(function(){
		// $('#content-wrapper').pullToRefresh({
	        // callback: function () {
	            // var deferred = $.Deferred();
// 	
	            // setTimeout(function () {
	                // // Simulate a refresh: add 3 items to the list
	                // //addItems(3);
	                // alert();
	                // deferred.resolve();
	            // }, 2000);
// 	
	            // return deferred.promise();
	        // }
	    // });
	// });
	
	// var REFRESHFLAG = false;
	// $(document).ready(function(){
		// $("#content-wrapper").scroll(function () {
			// if($(this).scrollTop() == 0 && REFRESHFLAG){
				// REFRESHFLAG = false;
				// $('.pullToRefresh').remove();
				// //little.views[userHistory[(userHistory.length)-1]]();
			// }else{
				// if($(this).scrollTop() < -100){
					// if($('.pullToRefresh').length == 0){
						// var temp =  '<div class="row pullToRefresh" style="padding-top:20px;">'+
										   		// '<span style="padding:20px 0 0 0;" class="center col s12">'+
										   			// '<i class="fa fa-spin fa-spinner"></i>&nbsp;&nbsp;'+
										   			// 'Loading...'+
										   		// '</span>'+
										    // '</div>';
// 						        
						// $('#content-wrapper').prepend(temp);
						// REFRESHFLAG = true;
					// }
				// }
			// }
		// });
	// });

    // window.document.addEventListener("scroll", function(){
        // if($('#content-wrapper').pageYOffset == 0){
            // little.views[userHistory[(userHistory.length)-1]]();
        // }
    // }, false);

