// var jquery = document.createElement('script');
 	// jquery.type = 'text/javascript';
    // jquery.src = url;
 
var jsFiles = {
				0 : {src:'cordova.js',id:"xdkJScordova_"},
				1 : {src:'js/app.js'},
				2 : {src:'js/init-app.js'},
				3 : {src:'xdk/init-dev.js'},
				4 : {src:'lib/jquery.min.js',type:'application/javascript'},
				5 : {src:'sidebar/js/hammer.js',type:'application/javascript'},
				6 : {src:'sidebar/js/jquery.hammer.js',type:'application/javascript'},
				7 : {src:'sidebar/js/swipe-hammer.js',type:'application/javascript'},
				8 : {src:'sidebar/js/sidebar.js',type:'application/javascript'},
				9 : {src:'js/index_user_scripts.js',type:'application/javascript'},
				10 : {src:'xdk/ad/bs_subpage.js',type:'application/javascript'}
			  };  
			  
			  
function load(){
	//alert();return;
	var BASE_URL = '../';
	var head = document.getElementsByTagName('head')[0];
	for(var i=0;i<=10;i++){
		// alert(jsFiles[i].src);
		var script = document.createElement('script');
			//script.type = 'text/javascript';
			script.src = BASE_URL+jsFiles[i].src;
			if(jsFiles[i].id!=undefined){
				script.id = jsFiles[i].id;
			}
			
			if(jsFiles[i].type!=undefined){
				script.type = jsFiles[i].type;
			}
		 head.appendChild(script);
	}	
}
//load();
//$("head").append('<script type="text/javascript" src="' + script + '"></script>');


	$(document).ready(function(){
		
		little.controllers.template();
		
		$(document).scroll(function(){
			//alert();
			$('[data-role="scroll-data-table"]').each(function(){
				var bottomDistance = parseInt($(this).attr('bottom-distance')); 
			
				if($(window).scrollTop() + $(window).height() > $(document).height() - bottomDistance) {
			    	//alert("near bottom!");
			    	//alert(bottomDistance);
			    	$('[data-role="scroll-data-table"]').trigger('scroll-data');	
			   	}
			});
		
		});
		
		
		$(document).on('scroll-data', '[data-role="scroll-data-table"]',function(){
			var url       = $(this).attr('data-url');
			var pageNo    = parseInt($(this).attr('data-page-no'));
			var limit     = parseInt($(this).attr('data-limit'));
			var isLoading = $(this).attr('is-loading');
			var callback  = $(this).attr('callback');
			var obj = this;
			if(isLoading == true || isLoading == 'true'){
				//alert(1);
				return;
			}
			//alert(url);return;
			$.ajax({
		        url: url+'/'+pageNo+'/'+limit,
		        type: 'POST',
		        beforeSend: function(){
		        	$(obj).attr('is-loading','true');
		        }, 
		        async: true,
	            success: function(response){
	            	//alert("hi");
	            	//alert(++pageNo);
	            	$(obj).attr('is-loading','false');
	            	$(obj).attr('data-page-no', ++pageNo)
		            var data=$.parseJSON(response);
		            little.views[callback](data,obj);
	            }
		     });
		});
		
	
	});
	
	var little = {};
	
	little.constants = {
		BASE_URL: window.location.origin+'/'
	};

	little.controllers = {};
	little.views = {};

	little.views.vw_dashboard = function(res){
		//
		//alert();
		$('#content-wrapper').html('Dashboard');
	}
	
	little.views.vw_listDeals = function(res){
		//console.log(res);
		//var cnt = res.result.length;
		var temp = '';
		temp += '<div data-role="scroll-data-table" bottom-distance="100" data-url="http://www.trideal.in/offers/getNewlyAddedDeals" data-page-no="1" data-limit="10" is-loading="false" callback="vw_listDealScrollData">';
		
		temp += '</div>';
		$('#content-wrapper').html(temp);
		$('[data-role="scroll-data-table"]').trigger('scroll-data');
	}
	
	little.views.vw_listDealScrollData = function(res,obj){
		//console.log(res);
		var cnt = res.result.length;
		var temp = '';
		//temp += '<div data-role="scroll-data-table" bottom-distance="100" data-url="http://www.trideal.in/offers/getNewlyAddedDeals" data-page-no="1" data-limit="10" is-loading="false">';
		for(var i=0;i<cnt;i++){
			temp += '<div style="background-color:#777;color:#fff;margin-bottom:20px;padding:10px;">';
			temp += '<div>'+res.result[i].dealName+'</div>';
			temp += '<div>'+res.result[i].merchantName+'</div>';
			temp += '<div>'+res.result[i].initialPayment+'</div>';
			temp += '</div>';
		}
		//temp += '</div>';
		$(obj).append(temp);
	}
	
	
	little.views.vw_showUsedCoupons = function(res){
		//
		$('#content-wrapper').html('Show Used Coupons');
	}
	
	little.views.vw_paymentHistory = function(res){
		//
		$('#content-wrapper').html('Payment History');
	}
	
	little.views.vw_reviews = function(res){
		//
		$('#content-wrapper').html('Reviews');
	}
	
	little.views.vw_redemption = function(res){
		//
		$('#content-wrapper').html('Redemption');
	}


	little.controllers.template = function(params){
		this.config = {
			contentFunc:function(){
				return 'Content function not defined';
			}
		}
		
		this.init = function(){
			var lo = this;
			lo.page();
			
			$(document).on('click','button[data-role="nav-item"]',function(){
				//alert();
				//var ajaxCall = $(this).attr('data-ref');
				var data = '';
				var url = $(this).attr('data-url');
				var callback = $(this).attr('data-callback');
				if(url=='' || url==undefined){
					little.views[callback](data);
					return;
				}
				$.ajax({
			        url: url,
			        type: 'POST',
			        async: true,
		            success: function(response){
			            var data=$.parseJSON(response);
			            //$$.views[THIS.config.responseHandler](data,THIS.config.responseWrapper);
			            little.views[callback](data);
		            }
			     });
				
				
				//alert(callback);
				
			});
		}
		
		this.header = function(){
			var lo = this;
			var temp = '<div class="grid grid-pad urow" data-uib="layout/row" data-ver="0">'+
	                        '<div class="col uib_col_5 col-0_4-12_4-4" data-uib="layout/col" data-ver="0">'+
	                            '<div class="widget-container content-area">'+
	                                '<button class="btn uib_w_5 d-margins btn-default" data-uib="twitter%20bootstrap/button" data-ver="1" id="leftMenu"><i class="glyphicon glyphicon-list button-icon-left" data-position="left"></i>'+ 
	                                '</button><span class="uib_shim"></span>'+
	                            '</div>'+
	                        '</div>'+
	                        '<div class="col uib_col_7 col-0_4-12_4-8" data-uib="layout/col" data-ver="0">'+
	                            '<div class="widget-container content-area vertical-col">'+
	                                '<div class="widget uib_w_13 d-margins" data-uib="media/text" data-ver="0">'+
	                                    '<div class="widget-container left-receptacle"></div>'+
	                                    '<div class="widget-container right-receptacle"></div>'+
	                                    '<div>'+
	                                        '<p>Home</p>'+
	                                    '</div>'+
	                                '</div><span class="uib_shim"></span>'+
	                            '</div>'+
	                        '</div>'+
	                        '<div class="col uib_col_6 col-0_4-12_4-8" data-uib="layout/col" data-ver="0">'+
	                            '<div class="widget-container content-area vertical-col">'+
	                                '<span class="uib_shim"></span>'+
	                            '</div>'+
	                        '</div>'+
	                        '<span class="uib_shim"></span>'+
	                    '</div>';
	    	return temp;
		}
		
		this.menu = function(){
			var lo = this;
			var temp = '<div class="inner-element uib_w_6 uib_sidebar leftbar bar-bg thumb-bg bar-gutter" data-uib="layout/left_sidebar" data-ver="1" data-anim="{\'style\':\'push\', \'v\':200, \'side\':\'left\', \'dur\':200, \'io\':false}">'+
		                    '<div class="sidebar-content content-area vertical-col">'+
		                        '<div class="grid grid-pad urow uib_row_4 row-height-4" data-uib="layout/row" data-ver="0">'+
		                            '<div class="col uib_col_8 col-0_12-12" data-uib="layout/col" data-ver="0">'+
		                                '<div class="widget-container content-area vertical-col left">'+
		                                    '<span class="uib_shim"></span>'+
		                                '</div>'+
		                            '</div>'+
		                            '<span class="uib_shim"></span>'+
		                        '</div>'+
		                        '<button data-role="nav-item" data-ref="dashboard" data-url="" data-callback="vw_dashboard" class="btn widget uib_w_7 d-margins btn-default" data-uib="twitter%20bootstrap/button" data-ver="1">Dashboard</button>'+
		                        '<button data-role="nav-item" data-ref="listDeals" data-url="" data-callback="vw_listDeals" class="btn widget uib_w_8 d-margins btn-default" data-uib="twitter%20bootstrap/button" data-ver="1">List of deals</button>'+
		                        '<button data-role="nav-item" data-ref="showUsedCoupons" data-url="" data-callback="vw_showUsedCoupons" class="btn widget uib_w_9 d-margins btn-default" data-uib="twitter%20bootstrap/button" data-ver="1">View used coupons</button>'+
		                        '<button data-role="nav-item" data-ref="paymentHistory" data-url="" data-callback="vw_paymentHistory" class="btn widget uib_w_10 d-margins btn-default" data-uib="twitter%20bootstrap/button" data-ver="1">Payment history</button>'+
		                        '<button data-role="nav-item" data-ref="reviews" data-url="" data-callback="vw_reviews" class="btn widget uib_w_11 d-margins btn-default" data-uib="twitter%20bootstrap/button" data-ver="1">Ratings &amp; Reviews</button>'+
		                        '<button data-role="nav-item" data-ref="redemption" data-url="" data-callback="vw_redemption" class="btn widget uib_w_12 d-margins btn-default" data-uib="twitter%20bootstrap/button" data-ver="1">Coupon Redemption</button>'+
		                    '</div>'+
		                '</div>';
			//alert(temp);
			return temp; 
		};
		
		this.page = function(){
			var lo = this;
			var temp = '';
			temp +=	'<div class="upage">'+
						'<div class="upage-outer">'+
			                '<div class="upage-content ac0 content-area vertical-col left" id="page_90_9">'+
			            		lo.header()+
			                    '<div class="grid grid-pad urow uib_row_5 row-height-5" data-uib="layout/row" data-ver="0">'+
			                        '<div class="col uib_col_9 col-0_12-12" data-uib="layout/col" data-ver="0">'+
			                            '<div class="widget-container content-area vertical-col">'+
			
			                                '<div class="widget uib_w_14 d-margins" data-uib="media/text" data-ver="0">'+
			                                    '<div class="widget-container left-receptacle"></div>'+
			                                    '<div class="widget-container right-receptacle"></div>'+
			                                    '<div id="content-wrapper">'+
			                                        //'<p>Content Body</p>'+
			                                    '</div>'+
			                                '</div><span class="uib_shim"></span>'+
			                            '</div>'+
			                        '</div>'+
			                        '<span class="uib_shim"></span>'+
			                    '</div>'+
			                '</div>'+
			                lo.menu()+
		            	'</div>'+
		          	'</div>';
	            //alert(temp);
	    	$('#mainWrapper').html(temp);
    	};
    	
    	this.init();
	};
